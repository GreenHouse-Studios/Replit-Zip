"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Folder } from "lucide-react"

interface ScreenshotFolderProps {
  name: string
  count?: number
  thumbnail?: string
  isProcessing?: boolean
  onClick?: () => void
}

export function ScreenshotFolder({ name, count, thumbnail, isProcessing = false, onClick }: ScreenshotFolderProps) {
  return (
    <Card className="p-3 cursor-pointer hover:shadow-md transition-all hover:scale-105" onClick={onClick}>
      <div className="flex flex-col items-center gap-2">
        <div className="relative">
          {thumbnail ? (
            <img src={thumbnail || "/placeholder.svg"} alt={name} className="w-12 h-16 rounded-lg object-cover" />
          ) : (
            <div className="w-12 h-16 bg-muted rounded-lg flex items-center justify-center">
              <Folder className="w-6 h-6 text-muted-foreground" />
            </div>
          )}

          {isProcessing && (
            <div className="absolute -top-1 -right-1">
              <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" />
            </div>
          )}
        </div>

        <div className="text-center">
          <p className="text-xs font-medium truncate max-w-full">{name}</p>
          {count !== undefined && (
            <Badge variant="secondary" className="text-xs mt-1">
              {count}
            </Badge>
          )}
        </div>
      </div>
    </Card>
  )
}
