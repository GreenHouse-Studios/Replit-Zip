import type { LucideIcon } from "lucide-react"

interface MetricCardProps {
  icon: LucideIcon
  value: string | number
  label: string
  variant?: "default" | "primary" | "success" | "warning"
}

export function MetricCard({ icon: Icon, value, label, variant = "default" }: MetricCardProps) {
  const getVariantStyles = () => {
    switch (variant) {
      case "primary":
        return "bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20 text-primary"
      case "success":
        return "bg-gradient-to-br from-green-500/10 to-green-400/5 border-green-500/20 text-green-600"
      case "warning":
        return "bg-gradient-to-br from-accent/10 to-yellow-400/5 border-accent/20 text-accent"
      default:
        return "gradient-card border-white/30"
    }
  }

  const getIconColor = () => {
    switch (variant) {
      case "primary":
        return "text-primary"
      case "success":
        return "text-green-500"
      case "warning":
        return "text-accent"
      default:
        return "text-muted-foreground"
    }
  }

  return (
    <div className={`p-4 rounded-2xl text-center interactive shadow-lg border ${getVariantStyles()}`}>
      <div className="flex justify-center mb-3">
        <div className="w-8 h-8 rounded-full bg-white/50 flex items-center justify-center">
          <Icon className={`text-xl font-bold leading-none mb-1 text-[rgba(183,40,40,1)] ${getIconColor()}`} />
        </div>
      </div>
      <div className="text-xl font-bold leading-none mb-1 text-black">{value}</div>
      <div className="text-xs text-muted-foreground leading-tight font-medium">{label}</div>
    </div>
  )
}
