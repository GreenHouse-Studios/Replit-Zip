"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface UserAvatarProps {
  username?: string
  avatarType?: "chimpanzee" | "elephant" | "orca" | "crocodile" | "tiger" | "custom"
  customImage?: string
  size?: "sm" | "md" | "lg"
  editable?: boolean
  onAvatarChange?: (type: string, image?: string) => void
  aspectRatio?: "square" | "portrait"
}

export function UserAvatar({
  username = "User",
  avatarType = "chimpanzee",
  customImage,
  size = "md",
  editable = false,
  onAvatarChange,
  aspectRatio = "square",
}: UserAvatarProps) {
  const [showSelector, setShowSelector] = useState(false)

  const sizeClasses = {
    sm: aspectRatio === "portrait" ? "w-8 h-12" : "w-8 h-8",
    md: aspectRatio === "portrait" ? "w-16 h-24" : "w-16 h-16",
    lg: aspectRatio === "portrait" ? "w-20 h-30" : "w-24 h-24",
  }

  const getAvatarImage = () => {
    const avatarImages = {
      chimpanzee: "/cute-chimpanzee-avatar.png",
      elephant: "/cute-elephant-avatar.png",
      orca: "/cute-orca-avatar.png",
      crocodile: "/cute-crocodile-avatar.png",
      tiger: "/cute-tiger-avatar.png",
    }
    return avatarImages[avatarType] || "/placeholder.svg"
  }

  const avatarTypes = ["chimpanzee", "elephant", "orca", "crocodile", "tiger"]

  return (
    <div className="relative">
      <div
        className={`${sizeClasses[size]} bg-gray-100 rounded-lg flex items-center justify-center relative overflow-hidden`}
      >
        <img
          src={customImage || getAvatarImage()}
          alt={`${avatarType} avatar`}
          className="w-full h-full object-cover"
        />

        {editable && (
          <Button
            size="icon"
            variant="secondary"
            className="absolute bottom-0 right-0 h-6 w-6 rounded-full opacity-80 hover:opacity-100"
            onClick={() => setShowSelector(!showSelector)}
          >
            <span className="text-xs">✏️</span>
          </Button>
        )}
      </div>

      {showSelector && editable && (
        <Card className="absolute top-full left-0 mt-2 p-3 z-10 min-w-48">
          <div className="grid grid-cols-3 gap-2 mb-3">
            {avatarTypes.map((type) => (
              <Button
                key={type}
                size="sm"
                variant={avatarType === type ? "default" : "outline"}
                onClick={() => {
                  onAvatarChange?.(type)
                  setShowSelector(false)
                }}
                className="p-1 h-12 flex flex-col items-center justify-center"
              >
                <img src={`/cute-${type}-avatar.png`} alt={type} className="w-6 h-6 object-cover rounded" />
                <span className="text-xs capitalize mt-1">{type}</span>
              </Button>
            ))}
          </div>
        </Card>
      )}
    </div>
  )
}
