import { Home, MessageCircle } from "lucide-react"

export function HomeIcon({ size = 24, className = "" }: { size?: number; className?: string }) {
  return <Home size={size} className={className} />
}

export function ChatIcon({ size = 24, className = "" }: { size?: number; className?: string }) {
  return <MessageCircle size={size} className={className} />
}

export function ShotIcon({ size = 24, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className={className}>
      {/* Corner brackets */}
      <path d="M3 3 L3 7 M3 3 L7 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M21 3 L21 7 M21 3 L17 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M3 21 L3 17 M3 21 L7 21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M21 21 L21 17 M21 21 L17 21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />

      {/* Inner frame */}
      <rect x="6" y="6" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="1.5" rx="1" />

      {/* Mountain landscape */}
      <path d="M8 15 L10 12 L12 13 L14 10 L16 12 L16 16 L8 16 Z" fill="currentColor" opacity="0.7" />

      {/* Sun */}
      <circle cx="14" cy="9" r="1.5" fill="currentColor" opacity="0.8" />
    </svg>
  )
}

export function AchievementIcon({ size = 24, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className={className}>
      {/* Sunburst background */}
      <g>
        {Array.from({ length: 16 }).map((_, i) => (
          <path
            key={i}
            d={`M12 1 L12 5`}
            stroke="currentColor"
            strokeWidth="0.8"
            transform={`rotate(${i * 22.5} 12 12)`}
            opacity="0.5"
          />
        ))}
      </g>
      {/* Outer circle */}
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.5" />
      {/* Trophy cup */}
      <path
        d="M8 8 L8 12 C8 14 10 16 12 16 C14 16 16 14 16 12 L16 8 Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      />
      {/* Trophy base */}
      <path d="M10 16 L14 16 L14 18 L10 18 Z" fill="currentColor" stroke="currentColor" strokeWidth="1.5" />
      <path d="M9 18 L15 18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      {/* Trophy handles */}
      <path d="M8 10 L6 10 C5 10 5 12 6 12 L8 12" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <path d="M16 10 L18 10 C19 10 19 12 18 12 L16 12" fill="none" stroke="currentColor" strokeWidth="1.5" />
      {/* Ribbon */}
      <path
        d="M12 19 L10 22 L12 21 L14 22 Z"
        fill="currentColor"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export function CaptureIcon({ size = 24, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className={className}>
      {/* Camera body */}
      <rect x="4" y="8" width="16" height="12" rx="2" fill="none" stroke="currentColor" strokeWidth="1.5" />
      {/* Camera lens */}
      <circle cx="12" cy="14" r="3" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="12" cy="14" r="1.5" fill="currentColor" opacity="0.3" />
      {/* Flash */}
      <rect x="8" y="6" width="3" height="2" rx="1" fill="currentColor" />
      {/* Viewfinder */}
      <circle cx="17" cy="10" r="0.5" fill="currentColor" />
      {/* Corner brackets for screenshot effect */}
      <path d="M2 6 L2 4 L4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.6" />
      <path d="M22 6 L22 4 L20 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.6" />
    </svg>
  )
}

export function QuestionsIcon({ size = 24, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className={className}>
      {/* Frame */}
      <rect x="3" y="3" width="18" height="18" rx="2" fill="none" stroke="currentColor" strokeWidth="1.5" />
      {/* Checkmark */}
      <path
        d="M8 12 L11 15 L16 9"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Corner accents */}
      <path d="M3 8 L6 8" stroke="currentColor" strokeWidth="1" opacity="0.5" />
      <path d="M18 8 L21 8" stroke="currentColor" strokeWidth="1" opacity="0.5" />
      <path d="M3 16 L6 16" stroke="currentColor" strokeWidth="1" opacity="0.5" />
      <path d="M18 16 L21 16" stroke="currentColor" strokeWidth="1" opacity="0.5" />
    </svg>
  )
}
