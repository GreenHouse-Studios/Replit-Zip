"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useState } from "react"

interface QuestionCardProps {
  id: number
  question: string
  options: string[]
  screenshots?: string[]
  isSelected?: boolean
  onSelect?: () => void
  onAnswer?: (questionId: number, answer: string) => void
  onOtherClick?: (questionId: number) => void
}

export function QuestionCard({
  id,
  question,
  options,
  screenshots = [],
  isSelected = false,
  onSelect,
  onAnswer,
  onOtherClick,
}: QuestionCardProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)

  const handleOptionClick = (option: string) => {
    if (option === "Other") {
      onOtherClick?.(id)
    } else {
      setSelectedAnswer(option)
      onAnswer?.(id, option)
    }
  }

  return (
    <Card
      className={`p-3 cursor-pointer transition-all duration-200 ${
        isSelected ? "ring-2 ring-primary bg-primary/5 border-primary/30 shadow-lg" : "hover:shadow-md border-gray-200"
      }`}
      onClick={onSelect}
    >
      <div className="flex gap-3">
        <div className="flex-1">
          <p className="text-sm font-medium mb-3 leading-relaxed text-gray-900">{question}</p>

          <div className="flex flex-wrap gap-2">
            {options.map((option) => (
              <Button
                key={option}
                size="sm"
                variant={selectedAnswer === option ? "default" : "outline"}
                onClick={(e) => {
                  e.stopPropagation()
                  handleOptionClick(option)
                }}
                className="text-xs"
              >
                {option}
              </Button>
            ))}
          </div>
        </div>

        {screenshots.length > 0 && (
          <div className="flex-shrink-0">
            <div className="flex gap-1">
              {screenshots.slice(0, 2).map((screenshot, index) => (
                <img
                  key={index}
                  src={screenshot || "/placeholder.svg?height=64&width=36&query=screenshot"}
                  alt={`Screenshot ${index + 1}`}
                  className="w-9 h-16 rounded object-cover"
                />
              ))}
              {screenshots.length > 2 && (
                <div className="w-9 h-16 rounded bg-muted flex items-center justify-center">
                  <span className="text-xs text-muted-foreground">+{screenshots.length - 2}</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </Card>
  )
}
