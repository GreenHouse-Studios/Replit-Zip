import { Card } from "@/components/ui/card"
import type { LucideIcon } from "lucide-react"

interface AnalyticsCardProps {
  title: string
  value: string | number
  subtitle?: string
  icon?: LucideIcon
  trend?: "up" | "down" | "neutral"
  trendValue?: string
  compact?: boolean // Added compact mode prop
}

export function AnalyticsCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend = "neutral",
  trendValue,
  compact = false, // Default to false for backward compatibility
}: AnalyticsCardProps) {
  const getTrendColor = () => {
    switch (trend) {
      case "up":
        return "text-green-600"
      case "down":
        return "text-red-600"
      default:
        return "text-muted-foreground"
    }
  }

  return (
    <Card className={compact ? "p-3" : "p-4"}>
      {" "}
      {/* Reduced padding for compact mode */}
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1">
          <p className={`text-muted-foreground mb-1 ${compact ? "text-xs" : "text-sm"}`}>{title}</p>{" "}
          {/* Smaller text for compact mode */}
          <p className={`font-bold leading-none ${compact ? "text-lg" : "text-2xl"}`}>{value}</p>{" "}
          {/* Smaller value text for compact mode */}
          {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
        </div>
        {Icon && <Icon className={`text-muted-foreground flex-shrink-0 ${compact ? "w-4 h-4" : "w-5 h-5"}`} />}{" "}
        {/* Smaller icon for compact mode */}
      </div>
      {trendValue && (
        <div className={`text-xs ${getTrendColor()}`}>
          {trend === "up" && "↗ "}
          {trend === "down" && "↘ "}
          {trendValue}
        </div>
      )}
    </Card>
  )
}
