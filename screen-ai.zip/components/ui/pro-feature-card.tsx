"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { type LucideIcon, Crown } from "lucide-react"

interface ProFeatureCardProps {
  title: string
  description?: string
  icon: LucideIcon
  isLocked?: boolean
  onClick?: () => void
}

export function ProFeatureCard({ title, description, icon: Icon, isLocked = true, onClick }: ProFeatureCardProps) {
  return (
    <Card
      className={`p-3 text-center cursor-pointer transition-all hover:shadow-md ${isLocked ? "opacity-75" : ""}`}
      onClick={onClick}
    >
      <div className="relative">
        <Icon className="w-6 h-6 mx-auto mb-2 text-muted-foreground" />
        {isLocked && <Crown className="w-3 h-3 absolute -top-1 -right-1 text-yellow-500" />}
      </div>

      <p className="text-xs font-medium mb-1">{title}</p>

      {description && <p className="text-xs text-muted-foreground">{description}</p>}

      {isLocked && (
        <Badge variant="secondary" className="text-xs mt-2">
          Pro
        </Badge>
      )}
    </Card>
  )
}
