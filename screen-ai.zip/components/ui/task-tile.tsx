"use client"

import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { ExternalLink, Trophy, Clock } from "lucide-react"

interface TaskTileProps {
  id: number
  title: string
  description: string
  isUrgent?: boolean
  isDaily?: boolean
  completed?: boolean
  dueDate?: string
  links?: string[]
  thumbnail?: string
  onToggle?: (id: number) => void
  onAchievementClick?: (id: number) => void
}

export function TaskTile({
  id,
  title,
  description,
  isUrgent = false,
  isDaily = false,
  completed = false,
  dueDate,
  links = [],
  thumbnail,
  onToggle,
  onAchievementClick,
}: TaskTileProps) {
  const getCheckboxStyle = () => {
    if (isUrgent) return "border-red-500 data-[state=checked]:bg-red-500 data-[state=checked]:border-red-500 bg-white"
    if (isDaily)
      return "border-amber-500 data-[state=checked]:bg-amber-500 data-[state=checked]:border-amber-500 bg-white"
    return "border-gray-400 data-[state=checked]:bg-primary data-[state=checked]:border-primary bg-white"
  }

  const getCardStyle = () => {
    if (isUrgent) return "border-red-200 bg-gradient-to-br from-red-50/80 to-orange-50/60"
    if (isDaily) return "border-amber-200 bg-gradient-to-br from-amber-50/80 to-yellow-50/60"
    return "gradient-card border-white/40"
  }

  return (
    <div className={`p-3 rounded-2xl interactive shadow-lg border ${getCardStyle()}`}>
      <div className="flex gap-3">
        <div className="flex-shrink-0 pt-0.5">
          <Checkbox
            checked={completed}
            onCheckedChange={() => onToggle?.(id)}
            className={`w-5 h-5 ${getCheckboxStyle()}`}
          />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1 pr-2">
              <h3 className="font-bold text-base leading-tight mb-0.5 text-gray-900">{title}</h3>
              {isUrgent && (
                <div className="flex items-center gap-1 mb-1">
                  <Clock className="w-3 h-3 text-red-500" />
                  <p className="text-xs text-red-600 font-semibold">{dueDate}</p>
                </div>
              )}
            </div>
            <Button
              size="icon"
              variant="ghost"
              className="flex-shrink-0 h-8 w-8 rounded-full hover:bg-accent/20"
              onClick={() => onAchievementClick?.(id)}
            >
              <Trophy className="w-4 h-4 text-amber-600 hover:text-amber-700 transition-colors" />
            </Button>
          </div>

          <p className="text-sm text-gray-600 mb-2 leading-relaxed">{description}</p>

          {links.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {links.map((link, index) => (
                <Button
                  key={index}
                  size="sm"
                  variant="secondary"
                  className="h-7 px-3 text-xs rounded-full bg-white/80 hover:bg-white border border-gray-200 interactive text-gray-700"
                >
                  {link}
                  <ExternalLink className="w-3 h-3 ml-1" />
                </Button>
              ))}
            </div>
          )}
        </div>

        <div className="flex-shrink-0">
          <div className="w-14 h-25 rounded-2xl overflow-hidden shadow-md border border-white/40">
            <img
              src={thumbnail || "/placeholder.svg?height=100&width=56&query=task thumbnail"}
              alt="Task thumbnail"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </div>
  )
}
