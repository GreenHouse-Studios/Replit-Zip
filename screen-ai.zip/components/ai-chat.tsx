"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Send, ImageIcon, Loader2, Crown } from "lucide-react"
import { aiService, type AIMessage } from "@/lib/ai-service"
import { useFeatureAccess } from "@/components/subscription/feature-gate"

interface AIChatProps {
  screenshot?: string
  onClose?: () => void
}

export function AIChat({ screenshot, onClose }: AIChatProps) {
  const [messages, setMessages] = useState<AIMessage[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const hasAdvancedAI = useFeatureAccess("Advanced AI processing")

  useEffect(() => {
    if (screenshot) {
      setMessages([
        {
          role: "user",
          content: "I have a screenshot I'd like you to analyze. What can you tell me about it?",
          screenshot,
          timestamp: Date.now(),
        },
      ])
      handleAIResponse([
        {
          role: "user",
          content: "I have a screenshot I'd like you to analyze. What can you tell me about it?",
          screenshot,
          timestamp: Date.now(),
        },
      ])
    }
  }, [screenshot])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: AIMessage = {
      role: "user",
      content: input,
      timestamp: Date.now(),
    }

    const newMessages = [...messages, userMessage]
    setMessages(newMessages)
    setInput("")

    await handleAIResponse(newMessages)
  }

  const handleAIResponse = async (currentMessages: AIMessage[]) => {
    setIsLoading(true)

    try {
      const stream = await aiService.chatWithAI(currentMessages, hasAdvancedAI)
      const reader = stream.getReader()
      const decoder = new TextDecoder()

      let aiResponse = ""
      const aiMessage: AIMessage = {
        role: "assistant",
        content: "",
        timestamp: Date.now(),
      }

      setMessages((prev) => [...prev, aiMessage])

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        const chunk = decoder.decode(value, { stream: true })
        aiResponse += chunk

        setMessages((prev) => prev.map((msg, idx) => (idx === prev.length - 1 ? { ...msg, content: aiResponse } : msg)))
      }
    } catch (error) {
      console.error("Error getting AI response:", error)
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Sorry, I encountered an error. Please try again.",
          timestamp: Date.now(),
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col h-full max-h-[600px]">
      {/* Pro indicator for advanced AI */}
      {hasAdvancedAI && (
        <div className="px-4 py-2 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 border-b">
          <div className="flex items-center gap-2 text-sm">
            <Crown className="w-4 h-4 text-yellow-500" />
            <span className="font-medium">Advanced AI (GPT-5) Active</span>
          </div>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message, idx) => (
          <div key={idx} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
            <Card
              className={`max-w-[80%] p-3 ${
                message.role === "user" ? "bg-blue-500 text-white" : "bg-gray-100 dark:bg-gray-800"
              }`}
            >
              {message.screenshot && (
                <div className="mb-2">
                  <ImageIcon className="w-4 h-4 inline mr-1" />
                  <span className="text-xs opacity-75">Screenshot attached</span>
                </div>
              )}
              <p className="text-sm whitespace-pre-wrap">{message.content}</p>
              {message.timestamp && (
                <p className="text-xs opacity-50 mt-1">{new Date(message.timestamp).toLocaleTimeString()}</p>
              )}
            </Card>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <Card className="bg-gray-100 dark:bg-gray-800 p-3">
              <Loader2 className="w-4 h-4 animate-spin" />
            </Card>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 border-t">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your screenshots..."
            disabled={isLoading}
            className="flex-1"
          />
          <Button type="submit" disabled={isLoading || !input.trim()}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </form>
    </div>
  )
}
