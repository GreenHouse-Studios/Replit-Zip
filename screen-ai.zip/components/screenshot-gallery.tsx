"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Trash2, Star, Eye, MoreHorizontal, X } from "lucide-react"
import { ScreenshotProcessor, type Screenshot } from "@/lib/screenshot-processor"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface ScreenshotGalleryProps {
  folder?: string
  showImportantOnly?: boolean
}

export function ScreenshotGallery({ folder, showImportantOnly = false }: ScreenshotGalleryProps) {
  const [screenshots, setScreenshots] = useState<Screenshot[]>([])
  const [selectedScreenshot, setSelectedScreenshot] = useState<Screenshot | null>(null)
  const processor = ScreenshotProcessor.getInstance()

  useEffect(() => {
    const loadScreenshots = () => {
      let allScreenshots = processor.getScreenshots()

      if (folder) {
        allScreenshots = processor.getScreenshotsByFolder(folder)
      }

      if (showImportantOnly) {
        allScreenshots = allScreenshots.filter((s) => s.isImportant)
      }

      setScreenshots(allScreenshots)
    }

    loadScreenshots()

    // Listen for processing updates
    const handleScreenshotProcessed = () => {
      loadScreenshots()
    }

    window.addEventListener("screenshotProcessed", handleScreenshotProcessed)

    return () => {
      window.removeEventListener("screenshotProcessed", handleScreenshotProcessed)
    }
  }, [folder, showImportantOnly])

  const handleDelete = (screenshotId: string) => {
    processor.deleteScreenshot(screenshotId)
    setScreenshots((prev) => prev.filter((s) => s.id !== screenshotId))
  }

  const handleToggleImportant = (screenshotId: string) => {
    processor.toggleImportant(screenshotId)
    setScreenshots((prev) => prev.map((s) => (s.id === screenshotId ? { ...s, isImportant: !s.isImportant } : s)))
  }

  const getClassificationColor = (classification?: string) => {
    const colors = {
      school: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
      work: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      personal: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
      shopping: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
      entertainment: "bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200",
      productivity: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
      other: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200",
    }
    return colors[classification as keyof typeof colors] || colors.other
  }

  if (screenshots.length === 0) {
    return (
      <Card className="p-8 text-center">
        <div className="text-muted-foreground">
          <Eye className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>No screenshots found</p>
          <p className="text-sm mt-1">Upload some screenshots to get started</p>
        </div>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        {screenshots.map((screenshot) => (
          <Card key={screenshot.id} className="overflow-hidden">
            <div className="relative">
              <img
                src={screenshot.url || "/placeholder.svg"}
                alt={screenshot.filename}
                className="w-full h-32 object-cover cursor-pointer"
                onClick={() => setSelectedScreenshot(screenshot)}
              />

              {screenshot.isImportant && (
                <Star className="absolute top-2 left-2 w-4 h-4 text-yellow-500 fill-current" />
              )}

              {!screenshot.processed && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <div className="text-white text-xs">Processing...</div>
                </div>
              )}

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="icon" variant="secondary" className="absolute top-2 right-2 h-6 w-6">
                    <MoreHorizontal className="w-3 h-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => handleToggleImportant(screenshot.id)}>
                    <Star className="w-4 h-4 mr-2" />
                    {screenshot.isImportant ? "Remove from Important" : "Mark as Important"}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleDelete(screenshot.id)} className="text-red-600">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <div className="p-3">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-muted-foreground truncate">{screenshot.filename}</p>
                {screenshot.classification && (
                  <Badge className={`text-xs ${getClassificationColor(screenshot.classification)}`}>
                    {screenshot.classification}
                  </Badge>
                )}
              </div>

              {screenshot.extractedText && (
                <p className="text-xs text-muted-foreground line-clamp-2">{screenshot.extractedText}</p>
              )}

              {screenshot.tasks && screenshot.tasks.length > 0 && (
                <Badge variant="secondary" className="text-xs mt-2">
                  {screenshot.tasks.length} task{screenshot.tasks.length !== 1 ? "s" : ""}
                </Badge>
              )}
            </div>
          </Card>
        ))}
      </div>

      {/* Screenshot Detail Modal */}
      {selectedScreenshot && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="max-w-md w-full max-h-[80vh] overflow-y-auto">
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold">Screenshot Details</h3>
                <Button size="icon" variant="ghost" onClick={() => setSelectedScreenshot(null)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <img
                src={selectedScreenshot.url || "/placeholder.svg"}
                alt={selectedScreenshot.filename}
                className="w-full rounded-lg mb-4"
              />

              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium">Filename</p>
                  <p className="text-sm text-muted-foreground">{selectedScreenshot.filename}</p>
                </div>

                {selectedScreenshot.extractedText && (
                  <div>
                    <p className="text-sm font-medium">Extracted Text</p>
                    <p className="text-sm text-muted-foreground">{selectedScreenshot.extractedText}</p>
                  </div>
                )}

                {selectedScreenshot.classification && (
                  <div>
                    <p className="text-sm font-medium">Classification</p>
                    <Badge className={getClassificationColor(selectedScreenshot.classification)}>
                      {selectedScreenshot.classification}
                    </Badge>
                  </div>
                )}

                {selectedScreenshot.tasks && selectedScreenshot.tasks.length > 0 && (
                  <div>
                    <p className="text-sm font-medium mb-2">Generated Tasks</p>
                    <div className="space-y-2">
                      {selectedScreenshot.tasks.map((task) => (
                        <Card key={task.id} className="p-2">
                          <p className="text-sm font-medium">{task.title}</p>
                          <p className="text-xs text-muted-foreground">{task.description}</p>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
