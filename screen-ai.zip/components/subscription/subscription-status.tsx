"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Crown, Calendar, CreditCard } from "lucide-react"
import { SubscriptionService, type SubscriptionStatus } from "@/lib/subscription-service"
import { SubscriptionModal } from "./subscription-modal"
import { useAuth } from "@/components/auth/auth-provider"

export function SubscriptionStatusCard() {
  const [subscriptionStatus, setSubscriptionStatus] = useState<SubscriptionStatus | null>(null)
  const [showUpgradeModal, setShowUpgradeModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()

  useEffect(() => {
    if (user) {
      loadSubscriptionStatus()
    }
  }, [user])

  const loadSubscriptionStatus = async () => {
    if (!user) return

    try {
      const status = await SubscriptionService.getSubscriptionStatus(user.uid)
      setSubscriptionStatus(status)
    } catch (error) {
      console.error("Failed to load subscription status:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleCancelSubscription = async () => {
    if (!user || !subscriptionStatus?.isActive) return

    if (confirm("Are you sure you want to cancel your subscription?")) {
      try {
        await SubscriptionService.cancelSubscription(user.uid)
        await loadSubscriptionStatus()
      } catch (error) {
        console.error("Failed to cancel subscription:", error)
      }
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!subscriptionStatus) {
    return null
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {subscriptionStatus.isActive ? (
              <Crown className="w-5 h-5 text-yellow-500" />
            ) : (
              <CreditCard className="w-5 h-5" />
            )}
            {subscriptionStatus.plan.name}
            {subscriptionStatus.isTrialing && <Badge variant="secondary">Trial</Badge>}
          </CardTitle>
          <CardDescription>
            {subscriptionStatus.isActive
              ? `Active until ${subscriptionStatus.currentPeriodEnd.toLocaleDateString()}`
              : "Free plan with basic features"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Plan Features */}
          <div className="space-y-2">
            <h4 className="font-semibold text-sm">Features included:</h4>
            <div className="grid grid-cols-1 gap-1">
              {subscriptionStatus.plan.features.slice(0, 3).map((feature, idx) => (
                <div key={idx} className="text-sm text-muted-foreground">
                  • {feature}
                </div>
              ))}
              {subscriptionStatus.plan.features.length > 3 && (
                <div className="text-sm text-muted-foreground">
                  +{subscriptionStatus.plan.features.length - 3} more features
                </div>
              )}
            </div>
          </div>

          {/* Trial Warning */}
          {subscriptionStatus.isTrialing && subscriptionStatus.trialEnd && (
            <div className="p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="w-4 h-4 text-yellow-600" />
                <span>
                  Trial ends on {subscriptionStatus.trialEnd.toLocaleDateString()}
                  {subscriptionStatus.trialEnd.getTime() - Date.now() < 7 * 24 * 60 * 60 * 1000 && " (Soon!)"}
                </span>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2">
            {!subscriptionStatus.isActive ? (
              <Button onClick={() => setShowUpgradeModal(true)} className="flex-1">
                <Crown className="w-4 h-4 mr-2" />
                Upgrade to Pro
              </Button>
            ) : (
              <>
                {subscriptionStatus.isTrialing && (
                  <Button onClick={() => setShowUpgradeModal(true)} className="flex-1">
                    Subscribe Now
                  </Button>
                )}
                <Button variant="outline" onClick={handleCancelSubscription} className="flex-1 bg-transparent">
                  Cancel Subscription
                </Button>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      <SubscriptionModal isOpen={showUpgradeModal} onClose={() => setShowUpgradeModal(false)} />
    </>
  )
}
