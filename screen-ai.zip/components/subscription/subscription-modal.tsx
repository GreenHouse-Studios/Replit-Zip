"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Crown, Loader2, CreditCard, Smartphone } from "lucide-react"
import { SUBSCRIPTION_PLANS, SubscriptionService } from "@/lib/subscription-service"
import { useAuth } from "@/components/auth/auth-provider"

interface SubscriptionModalProps {
  isOpen: boolean
  onClose: () => void
  defaultPlan?: string
}

export function SubscriptionModal({ isOpen, onClose, defaultPlan = "pro_monthly" }: SubscriptionModalProps) {
  const [selectedPlan, setSelectedPlan] = useState(defaultPlan)
  const [isProcessing, setIsProcessing] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState<"card" | "paypal" | "apple_pay" | "google_pay">("card")
  const [showPayment, setShowPayment] = useState(false)
  const { user } = useAuth()

  const handleStartTrial = async () => {
    if (!user) return

    setIsProcessing(true)
    try {
      await SubscriptionService.startFreeTrial(user.uid)
      onClose()
    } catch (error) {
      console.error("Failed to start trial:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleSubscribe = async () => {
    if (!user) return

    setIsProcessing(true)
    try {
      const result = await SubscriptionService.processPayment(user.uid, selectedPlan, paymentMethod)

      if (result.success) {
        onClose()
      } else {
        alert(`Payment failed: ${result.error}`)
      }
    } catch (error) {
      console.error("Subscription failed:", error)
      alert("Subscription failed. Please try again.")
    } finally {
      setIsProcessing(false)
    }
  }

  const plans = [SUBSCRIPTION_PLANS.pro_monthly, SUBSCRIPTION_PLANS.pro_yearly]

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crown className="w-5 h-5 text-yellow-500" />
            Upgrade to Screen AI Pro
          </DialogTitle>
        </DialogHeader>

        {!showPayment ? (
          <div className="space-y-4">
            {/* Free Trial Offer */}
            <Card className="border-2 border-blue-500 bg-blue-50 dark:bg-blue-950/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Badge variant="secondary" className="bg-blue-500 text-white">
                    FREE TRIAL
                  </Badge>
                </CardTitle>
                <CardDescription>Try all Pro features free for 31 days</CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={handleStartTrial} disabled={isProcessing} className="w-full">
                  {isProcessing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Start Free Trial
                </Button>
                <p className="text-xs text-muted-foreground mt-2 text-center">
                  No credit card required • Cancel anytime
                </p>
              </CardContent>
            </Card>

            {/* Plan Selection */}
            <div className="space-y-3">
              {plans.map((plan) => (
                <Card
                  key={plan.id}
                  className={`cursor-pointer transition-all ${
                    selectedPlan === plan.id ? "border-2 border-blue-500 bg-blue-50 dark:bg-blue-950/20" : ""
                  }`}
                  onClick={() => setSelectedPlan(plan.id)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{plan.name}</CardTitle>
                      {plan.interval === "yearly" && (
                        <Badge variant="secondary" className="bg-green-500 text-white">
                          Save 17%
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-2xl font-bold">${plan.price}</span>
                      <span className="text-muted-foreground">/{plan.interval === "yearly" ? "year" : "month"}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {plan.features.slice(0, 4).map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm">
                          <Check className="w-4 h-4 text-green-500" />
                          <span>{feature}</span>
                        </div>
                      ))}
                      {plan.features.length > 4 && (
                        <div className="text-sm text-muted-foreground">+{plan.features.length - 4} more features</div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Button onClick={() => setShowPayment(true)} className="w-full" size="lg">
              Continue to Payment
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Selected Plan Summary */}
            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold">{SUBSCRIPTION_PLANS[selectedPlan].name}</h3>
                    <p className="text-sm text-muted-foreground">
                      ${SUBSCRIPTION_PLANS[selectedPlan].price}/
                      {SUBSCRIPTION_PLANS[selectedPlan].interval === "yearly" ? "year" : "month"}
                    </p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setShowPayment(false)}>
                    Change
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Payment Methods */}
            <div className="space-y-3">
              <h3 className="font-semibold">Payment Method</h3>

              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant={paymentMethod === "card" ? "default" : "outline"}
                  onClick={() => setPaymentMethod("card")}
                  className="flex items-center gap-2"
                >
                  <CreditCard className="w-4 h-4" />
                  Card
                </Button>
                <Button
                  variant={paymentMethod === "paypal" ? "default" : "outline"}
                  onClick={() => setPaymentMethod("paypal")}
                >
                  PayPal
                </Button>
                <Button
                  variant={paymentMethod === "apple_pay" ? "default" : "outline"}
                  onClick={() => setPaymentMethod("apple_pay")}
                  className="flex items-center gap-2"
                >
                  <Smartphone className="w-4 h-4" />
                  Apple Pay
                </Button>
                <Button
                  variant={paymentMethod === "google_pay" ? "default" : "outline"}
                  onClick={() => setPaymentMethod("google_pay")}
                  className="flex items-center gap-2"
                >
                  <Smartphone className="w-4 h-4" />
                  Google Pay
                </Button>
              </div>
            </div>

            {/* Payment Form Simulation */}
            {paymentMethod === "card" && (
              <Card>
                <CardContent className="pt-4 space-y-3">
                  <div className="h-10 bg-gray-100 dark:bg-gray-800 rounded border flex items-center px-3 text-sm text-muted-foreground">
                    Card Number: •••• •••• •••• 1234
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="h-10 bg-gray-100 dark:bg-gray-800 rounded border flex items-center px-3 text-sm text-muted-foreground">
                      MM/YY
                    </div>
                    <div className="h-10 bg-gray-100 dark:bg-gray-800 rounded border flex items-center px-3 text-sm text-muted-foreground">
                      CVC
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Button onClick={handleSubscribe} disabled={isProcessing} className="w-full" size="lg">
              {isProcessing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Subscribe Now
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              By subscribing, you agree to our Terms of Service and Privacy Policy. Cancel anytime.
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
