"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Crown } from "lucide-react"
import { SubscriptionModal } from "./subscription-modal"
import { useAuth } from "@/components/auth/auth-provider"

interface FeatureGateProps {
  feature: string
  children: React.ReactNode
  fallback?: React.ReactNode
  showUpgrade?: boolean
}

export function FeatureGate({ feature, children, fallback, showUpgrade = true }: FeatureGateProps) {
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false)
  const { userProfile } = useAuth()

  // Check if user has access to the feature
  const hasAccess = userProfile?.subscription?.isPro || false

  // For demo purposes, we'll simulate feature access
  const proFeatures = [
    "Advanced AI processing",
    "Export to Notes apps",
    "Auto-download images",
    "Cloud storage",
    "Create offline PDFs",
    "Advanced analytics",
  ]

  const isProFeature = proFeatures.some((f) => feature.toLowerCase().includes(f.toLowerCase()))

  if (!isProFeature || hasAccess) {
    return <>{children}</>
  }

  if (fallback) {
    return <>{fallback}</>
  }

  if (!showUpgrade) {
    return null
  }

  return (
    <>
      <Card className="border-2 border-dashed border-gray-300 dark:border-gray-600">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2 text-lg">
            <Crown className="w-5 h-5 text-yellow-500" />
            Pro Feature
          </CardTitle>
          <CardDescription>Upgrade to Screen AI Pro to unlock {feature}</CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <Button onClick={() => setShowSubscriptionModal(true)} className="w-full">
            <Crown className="w-4 h-4 mr-2" />
            Upgrade to Pro
          </Button>
        </CardContent>
      </Card>

      <SubscriptionModal isOpen={showSubscriptionModal} onClose={() => setShowSubscriptionModal(false)} />
    </>
  )
}

// Hook for checking feature access
export function useFeatureAccess(feature: string): boolean {
  const { userProfile } = useAuth()

  const proFeatures = [
    "Advanced AI processing",
    "Export to Notes apps",
    "Auto-download images",
    "Cloud storage",
    "Create offline PDFs",
    "Advanced analytics",
  ]

  const isProFeature = proFeatures.some((f) => feature.toLowerCase().includes(f.toLowerCase()))

  if (!isProFeature) return true

  return userProfile?.subscription?.isPro || false
}
