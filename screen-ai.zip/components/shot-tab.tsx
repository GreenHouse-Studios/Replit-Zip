"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Settings, Download, FileText, Star, BarChart3, Clock, Smartphone, Crown } from "lucide-react"
import { UserAvatar } from "@/components/ui/user-avatar"
import { AnalyticsCard } from "@/components/ui/analytics-card"
import { ScreenshotGallery } from "@/components/screenshot-gallery"
import { SubscriptionModal } from "@/components/subscription/subscription-modal"
// Added background service components
import { BackgroundStatusCard } from "@/components/background-status"
import { NotificationCenter } from "@/components/notification-center"

export function ShotTab() {
  const [userProfile, setUserProfile] = useState({
    username: "ScreenShot Founder",
    avatarType: "chimpanzee" as const,
    customImage: undefined as string | undefined,
  })

  const [activeSection, setActiveSection] = useState<"overview" | "archive" | "important" | "settings" | "studio">(
    "overview",
  )
  const [showUpgradeModal, setShowUpgradeModal] = useState(false)

  const analytics = {
    avgDaily: 15,
    firstScreenshot: "8:30 AM",
    timeInApp: "2h 15m",
    topSources: ["Chrome", "Instagram", "Messages"],
  }

  const handleAvatarChange = (type: string, image?: string) => {
    setUserProfile({
      ...userProfile,
      avatarType: type as any,
      customImage: image,
    })
  }

  const proFeatures = [
    "Custom Request",
    "Extract text + search web for context → generate downloadable PDF/CSV lists",
    "Export text to user's notes app (Google Keep, Apple Notes, Obsidian) via API",
    "Auto-download images found in screenshots to offline folder",
    "Store processed screenshots in cloud up to 30 days after deletion",
    "Auto-create reminders/tasks in productivity apps from screenshot info",
  ]

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-end">
        <Button size="icon" variant="ghost" onClick={() => setActiveSection("settings")}>
          <Settings className="w-5 h-5" />
        </Button>
      </div>

      {activeSection === "overview" && (
        <>
          {/* Profile */}
          <div className="p-4 border-b border-border -mt-2">
            <div className="flex items-center gap-3 mb-4">
              <UserAvatar
                username={userProfile.username}
                avatarType={userProfile.avatarType}
                customImage={userProfile.customImage}
                size="lg"
                editable={true}
                onAvatarChange={handleAvatarChange}
                aspectRatio="portrait"
              />
              <div>
                <h2 className="font-bold text-gray-900">{userProfile.username}</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  className="p-0 h-auto text-sm text-primary hover:text-primary/80"
                  onClick={() => setActiveSection("studio")}
                >
                  Studio &gt;
                </Button>
              </div>
            </div>
          </div>

          {/* Archive Sections */}
          <div className="p-4 space-y-3">
            <Button
              variant="outline"
              className="w-full justify-start gap-2 bg-transparent"
              onClick={() => setActiveSection("archive")}
            >
              <Download className="w-4 h-4" />
              Shots - Archive
            </Button>

            <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
              <FileText className="w-4 h-4" />
              Wayback AI
            </Button>

            {/* Important Screenshots */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-bold flex items-center gap-2 text-gray-900">
                  <Star className="w-4 h-4 text-yellow-500" />
                  Important Screenshots
                </h3>
                <Button size="sm" variant="ghost" onClick={() => setActiveSection("important")}>
                  View All
                </Button>
              </div>
              <ScreenshotGallery showImportantOnly={true} />
            </div>

            <div className="space-y-4">
              <div className="bg-gradient-to-br from-red-50 to-orange-50 border border-red-200 rounded-xl p-4">
                <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <Crown className="w-5 h-5 text-red-600" />
                  Pro Features
                </h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  {proFeatures.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-red-600 rounded-full mt-2 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <Button
                onClick={() => setShowUpgradeModal(true)}
                className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white shadow-lg"
                size="lg"
              >
                <Crown className="w-5 h-5 mr-2 text-yellow-400" />
                Upgrade to Pro
              </Button>
            </div>
          </div>
        </>
      )}

      {/* Separate Studio section */}
      {activeSection === "studio" && (
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-900">Studio Analytics</h2>
            <Button size="sm" variant="ghost" onClick={() => setActiveSection("overview")}>
              ← Back
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-2 mb-4">
            <AnalyticsCard
              title="Avg daily"
              value={analytics.avgDaily}
              icon={BarChart3}
              trend="up"
              trendValue="+12%"
              compact={true}
            />
            <AnalyticsCard title="First shot" value={analytics.firstScreenshot} icon={Clock} compact={true} />
            <AnalyticsCard
              title="Time in app"
              value={analytics.timeInApp}
              icon={Smartphone}
              trend="up"
              trendValue="+5min"
              compact={true}
            />
            <AnalyticsCard
              title="Top sources"
              value={analytics.topSources.length}
              subtitle={analytics.topSources.join(", ")}
              compact={true}
            />
          </div>

          {/* Weekly Graph Placeholder */}
          <div className="h-20 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-lg flex items-center justify-center border border-border">
            <span className="text-muted-foreground text-sm">Weekly Activity Graph</span>
          </div>
        </div>
      )}

      {activeSection === "settings" && (
        <div className="p-4 space-y-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">Settings & Status</h2>
            <Button size="sm" variant="ghost" onClick={() => setActiveSection("overview")}>
              ← Back
            </Button>
          </div>

          {/* Added background service status and notification center */}
          <BackgroundStatusCard />
          <NotificationCenter />
        </div>
      )}

      {activeSection === "archive" && (
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">Screenshot Archive</h2>
            <Button size="sm" variant="ghost" onClick={() => setActiveSection("overview")}>
              ← Back
            </Button>
          </div>
          <ScreenshotGallery />
        </div>
      )}

      {activeSection === "important" && (
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">Important Screenshots</h2>
            <Button size="sm" variant="ghost" onClick={() => setActiveSection("overview")}>
              ← Back
            </Button>
          </div>
          <ScreenshotGallery showImportantOnly={true} />
        </div>
      )}

      <SubscriptionModal isOpen={showUpgradeModal} onClose={() => setShowUpgradeModal(false)} />
    </div>
  )
}
