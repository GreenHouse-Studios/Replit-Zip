"use client"

import { useState } from "react"
import { Progress } from "@/components/ui/progress"
import { Clock, Target, HardDrive, Sparkles, Trophy } from "lucide-react"
import { TaskTile } from "@/components/ui/task-tile"
import { MetricCard } from "@/components/ui/metric-card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export function HomeTab() {
  const [tasks, setTasks] = useState([
    {
      id: 1,
      title: "Watch the WVFRM Podcast",
      description: "You haven't watched this episode",
      isUrgent: false,
      isDaily: true,
      completed: false,
      links: ["Link"],
      thumbnail: "/podcast-thumbnail.png",
    },
    {
      id: 2,
      title: "Apply to top 5 colleges",
      description: "They are only 5 in USA",
      isUrgent: true,
      isDaily: false,
      completed: false,
      dueDate: "3.15.25 23H00",
      links: ["Link 1", "Link 2", "Link 3"],
      thumbnail: "/college-application-concept.png",
    },
  ])

  const [showAchievements, setShowAchievements] = useState(false)
  const [completedTasksHistory, setCompletedTasksHistory] = useState([
    { id: 101, title: "Review quarterly reports", completedAt: "2024-01-10", category: "Work" },
    { id: 102, title: "Book dentist appointment", completedAt: "2024-01-09", category: "Personal" },
    { id: 103, title: "Update portfolio website", completedAt: "2024-01-08", category: "Projects" },
  ])

  const completedTasks = tasks.filter((task) => task.completed).length
  const totalScreenshots = 15
  const processedScreenshots = 8
  const progressPercentage = (processedScreenshots / totalScreenshots) * 100

  const handleTaskToggle = (taskId: number) => {
    setTasks(
      tasks.map((task) => {
        if (task.id === taskId && !task.completed) {
          const completedTask = tasks.find((t) => t.id === taskId)
          if (completedTask) {
            setCompletedTasksHistory((prev) => [
              {
                id: taskId,
                title: completedTask.title,
                completedAt: new Date().toISOString().split("T")[0],
                category: completedTask.isUrgent ? "Urgent" : completedTask.isDaily ? "Daily" : "General",
              },
              ...prev,
            ])
          }
        }
        return task.id === taskId ? { ...task, completed: !task.completed } : task
      }),
    )
  }

  const handleAchievementClick = (taskId: number) => {
    console.log("Show achievements for task:", taskId)
  }

  const handleAchievementsView = () => {
    setShowAchievements(true)
  }

  const sortedTasks = [...tasks].sort((a, b) => {
    if (a.isUrgent && !b.isUrgent) return -1
    if (!a.isUrgent && b.isUrgent) return 1
    if (a.isDaily && !b.isDaily) return -1
    if (!a.isDaily && b.isDaily) return 1
    return 0
  })

  return (
    <div className="flex flex-col h-full animate-fade-in">
      {/* Header */}
      <div className="p-6 glass border-b border-white/20">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 gradient-primary rounded-2xl flex items-center justify-center shadow-premium">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold leading-10 text-gray-900">Screen AI</h1>
            </div>
          </div>
          <Button
            size="icon"
            variant="ghost"
            className="w-10 h-10 bg-accent/20 rounded-full flex items-center justify-center animate-float hover:bg-accent/30 transition-colors"
            onClick={handleAchievementsView}
          >
            <Trophy className="w-5 h-5 text-amber-600" />
          </Button>
        </div>

        {/* Progress Bar */}
        <div className="mb-6 animate-slide-up">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-900">Screenshot Processing</span>
            <span className="text-sm font-bold text-primary">{Math.round(progressPercentage)}%</span>
          </div>
          <Progress value={progressPercentage} className="h-3 bg-gray-200" />
          <p className="text-xs text-gray-700 mt-2">
            {processedScreenshots} of {totalScreenshots} screenshots processed
          </p>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-3 gap-3 animate-scale-in">
          <MetricCard icon={Clock} value="44mins" label="est. time" variant="default" />
          <MetricCard
            icon={Target}
            value="12"
            label="daily"
            variant="warning"
            className="bg-yellow-50 border-yellow-200 [&_.metric-value]:text-muted-foreground [&_.metric-label]:text-muted-foreground [&_.metric-icon]:text-primary"
          />
          <MetricCard icon={HardDrive} value="3.12GB" label="saved" variant="success" />
        </div>
      </div>

      {/* Tasks */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-bold text-gray-900">Tasks</h2>
          <span className="text-xs text-gray-600">{sortedTasks.length} tasks</span>
        </div>

        {sortedTasks.map((task, index) => (
          <div key={task.id} className="animate-slide-up" style={{ animationDelay: `${index * 0.1}s` }}>
            <TaskTile {...task} onToggle={handleTaskToggle} onAchievementClick={handleAchievementClick} />
          </div>
        ))}
      </div>

      {/* Achievements Modal */}
      <Dialog open={showAchievements} onOpenChange={setShowAchievements}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-600" />
              Achievements
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-gray-600">Total completed tasks: {completedTasksHistory.length}</div>
            <div className="max-h-60 overflow-y-auto space-y-2">
              {completedTasksHistory.map((task) => (
                <div key={task.id} className="p-3 bg-gray-50 rounded-lg">
                  <div className="font-medium text-gray-900">{task.title}</div>
                  <div className="text-xs text-gray-500 mt-1">
                    {task.category} • Completed {task.completedAt}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
