"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Activity, Bell, CheckCircle, Clock, AlertCircle, Play, Pause, RefreshCw, Settings } from "lucide-react"
import { backgroundService, type BackgroundTask } from "@/lib/background-service"

export function BackgroundStatusCard() {
  const [status, setStatus] = useState(backgroundService.getStatus())
  const [recentTasks, setRecentTasks] = useState<BackgroundTask[]>([])
  const [isExpanded, setIsExpanded] = useState(false)

  useEffect(() => {
    // Update status every 5 seconds
    const interval = setInterval(() => {
      setStatus(backgroundService.getStatus())
      setRecentTasks(backgroundService.getTaskHistory().slice(0, 5))
    }, 5000)

    // Listen for task updates
    const unsubscribe = backgroundService.onTaskUpdate((task) => {
      setStatus(backgroundService.getStatus())
      setRecentTasks(backgroundService.getTaskHistory().slice(0, 5))
    })

    return () => {
      clearInterval(interval)
      unsubscribe()
    }
  }, [])

  const handleToggleService = () => {
    if (status.isRunning) {
      backgroundService.stop()
    } else {
      backgroundService.start()
    }
  }

  const getTaskIcon = (type: string) => {
    switch (type) {
      case "screenshot_detection":
        return <Activity className="w-4 h-4" />
      case "processing":
        return <RefreshCw className="w-4 h-4" />
      case "cleanup":
        return <Settings className="w-4 h-4" />
      case "sync":
        return <RefreshCw className="w-4 h-4" />
      case "analytics":
        return <Activity className="w-4 h-4" />
      default:
        return <Clock className="w-4 h-4" />
    }
  }

  const getStatusColor = (taskStatus: string) => {
    switch (taskStatus) {
      case "completed":
        return "text-green-500"
      case "running":
        return "text-blue-500"
      case "failed":
        return "text-red-500"
      default:
        return "text-gray-500"
    }
  }

  const totalTasks = status.pendingTasks + status.runningTasks + status.completedTasks + status.failedTasks
  const completionRate = totalTasks > 0 ? (status.completedTasks / totalTasks) * 100 : 0

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Background Services
              <Badge variant={status.isRunning ? "default" : "secondary"}>
                {status.isRunning ? "Active" : "Stopped"}
              </Badge>
            </CardTitle>
            <CardDescription>
              {status.isRunning ? "Monitoring screenshots and processing tasks" : "Background services are paused"}
            </CardDescription>
          </div>
          <Button size="sm" variant="outline" onClick={handleToggleService}>
            {status.isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Service Status */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Task Completion</span>
              <span className="font-medium">{Math.round(completionRate)}%</span>
            </div>
            <Progress value={completionRate} className="h-2" />
          </div>
          <div className="space-y-2">
            <div className="text-sm text-muted-foreground">Active Tasks</div>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-yellow-500" />
                <span>{status.pendingTasks}</span>
              </div>
              <div className="flex items-center gap-1">
                <RefreshCw className="w-3 h-3 text-blue-500" />
                <span>{status.runningTasks}</span>
              </div>
              <div className="flex items-center gap-1">
                <CheckCircle className="w-3 h-3 text-green-500" />
                <span>{status.completedTasks}</span>
              </div>
              {status.failedTasks > 0 && (
                <div className="flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 text-red-500" />
                  <span>{status.failedTasks}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Recent Tasks */}
        {recentTasks.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium">Recent Activity</h4>
              <Button size="sm" variant="ghost" onClick={() => setIsExpanded(!isExpanded)}>
                {isExpanded ? "Show Less" : "Show More"}
              </Button>
            </div>
            <div className="space-y-2">
              {recentTasks.slice(0, isExpanded ? 10 : 3).map((task) => (
                <div key={task.id} className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                  <div className={getStatusColor(task.status)}>{getTaskIcon(task.type)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium capitalize">{task.type.replace("_", " ")}</div>
                    <div className="text-xs text-muted-foreground">
                      {task.completedAt
                        ? `Completed ${task.completedAt.toLocaleTimeString()}`
                        : `Started ${task.createdAt.toLocaleTimeString()}`}
                    </div>
                  </div>
                  <Badge
                    variant={
                      task.status === "completed" ? "default" : task.status === "failed" ? "destructive" : "secondary"
                    }
                    className="text-xs"
                  >
                    {task.status}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Notification Status */}
        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            <span className="text-sm">Push Notifications</span>
          </div>
          <Badge variant={Notification.permission === "granted" ? "default" : "secondary"}>
            {Notification.permission === "granted" ? "Enabled" : "Disabled"}
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}
