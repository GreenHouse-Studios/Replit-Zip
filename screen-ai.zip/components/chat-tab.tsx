"use client"

import { useState } from "react"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Send, Search, HelpCircle, Sparkles } from "lucide-react"
import { ScreenshotFolder } from "@/components/ui/screenshot-folder"
import { QuestionCard } from "@/components/ui/question-card"
import { ScreenshotUpload } from "@/components/screenshot-upload"
import { ProcessingStatus } from "@/components/processing-status"
import { handleUploadComplete } from "@/utils/upload-utils" // Declare or import the handleUploadComplete function
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export function ChatTab() {
  const [message, setMessage] = useState("")
  const [isInputFocused, setIsInputFocused] = useState(false)
  const [showUpload, setShowUpload] = useState(false)
  const [showQuestions, setShowQuestions] = useState(false)
  const [selectedQuestionId, setSelectedQuestionId] = useState<number | null>(null)
  const [showQuestionsHistory, setShowQuestionsHistory] = useState(false)
  const [answeredQuestionsHistory, setAnsweredQuestionsHistory] = useState([
    {
      id: 201,
      question: "Should I turn this into a list?",
      answer: "Yes",
      answeredAt: "2024-01-10",
      screenshot: "/screenshot-1.png",
    },
    {
      id: 202,
      question: "Export this to PDF?",
      answer: "No",
      answeredAt: "2024-01-09",
      screenshot: "/college-application-concept.png",
    },
    {
      id: 203,
      question: "Create reminder for this?",
      answer: "Yes",
      answeredAt: "2024-01-08",
      screenshot: "/podcast-thumbnail.png",
    },
  ])

  const completedQuestions = 4
  const dailyGoal = 7
  const progressPercentage = (completedQuestions / dailyGoal) * 100

  const folders = [
    { name: "Screenshots", count: 23, thumbnail: "/screenshot-1.png" },
    { name: "Personal", count: 12, thumbnail: "/important-screenshot-1.png" },
    { name: "School", count: 8, thumbnail: "/college-application-concept.png" },
  ]

  const processingItems = [
    { name: "Export", isProcessing: true, thumbnail: "/podcast-thumbnail.png" },
    { name: "Threads", isProcessing: false, thumbnail: "/screenshot-1.png" },
    { name: "Youtube Lists", isProcessing: true, thumbnail: "/college-application-concept.png" },
  ]

  const questions = [
    {
      id: 1,
      question: "Should I turn this into a list?",
      options: ["Yes", "No", "Other"],
      screenshots: ["/screenshot-1.png"],
    },
  ]

  const handleQuestionSelect = (questionId: number) => {
    setSelectedQuestionId(questionId)
    setIsInputFocused(true)
  }

  const handleQuestionAnswer = (questionId: number, answer: string) => {
    const question = questions.find((q) => q.id === questionId)
    if (question) {
      setAnsweredQuestionsHistory((prev) => [
        {
          id: questionId,
          question: question.question,
          answer: answer,
          answeredAt: new Date().toISOString().split("T")[0],
          screenshot: question.screenshots[0],
        },
        ...prev,
      ])
    }
    console.log(`Question ${questionId} answered: ${answer}`)
    setSelectedQuestionId(null)
  }

  const handleOtherClick = (questionId: number) => {
    console.log(`Other option clicked for question ${questionId}`)
    setSelectedQuestionId(questionId)
    setIsInputFocused(true)
  }

  const handleQuestionsView = () => {
    setShowQuestionsHistory(true)
  }

  const handleSendAnswer = () => {
    if (selectedQuestionId && message.trim()) {
      handleQuestionAnswer(selectedQuestionId, message)
      setMessage("")
      setSelectedQuestionId(null)
    } else if (message.trim()) {
      console.log("Sending message:", message)
      setMessage("")
    } else {
      console.log("Search screenshots")
    }
  }

  return (
    <div className="flex flex-col h-full">
      {!isInputFocused && (
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 gradient-primary rounded-2xl flex items-center justify-center shadow-premium">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 leading-10">Screen AI</h1>
            </div>
            <Button
              size="icon"
              variant="ghost"
              className="w-10 h-10 bg-accent/20 rounded-full flex items-center justify-center hover:bg-accent/30 transition-colors"
              onClick={handleQuestionsView}
            >
              <HelpCircle className="w-5 h-5 text-primary" />
            </Button>
          </div>

          <div className="mb-4">
            <ProcessingStatus />
          </div>

          <div className="mb-4">
            <h2 className="text-sm font-medium mb-2">Screenshots</h2>
            <div className="grid grid-cols-3 gap-2">
              {folders.map((folder) => (
                <ScreenshotFolder
                  key={folder.name}
                  name={folder.name}
                  count={folder.count}
                  thumbnail={folder.thumbnail}
                />
              ))}
            </div>
          </div>

          <div className="mb-4">
            <h2 className="text-sm font-medium mb-2">Processing</h2>
            <div className="grid grid-cols-3 gap-2">
              {processingItems.map((item) => (
                <ScreenshotFolder
                  key={item.name}
                  name={item.name}
                  isProcessing={item.isProcessing}
                  thumbnail={item.thumbnail}
                />
              ))}
            </div>
          </div>

          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-900">Daily Questions</span>
              <span className="text-sm font-bold text-primary">{Math.round(progressPercentage)}%</span>
            </div>
            <Progress value={progressPercentage} className="h-3 bg-gray-200" />
            <p className="text-xs text-gray-700 mt-2">
              {completedQuestions}/{dailyGoal} daily questions completed
            </p>
          </div>
        </div>
      )}

      {showUpload && (
        <div className="absolute inset-0 bg-background z-10 p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">Upload Screenshots</h2>
            <Button variant="ghost" onClick={() => setShowUpload(false)}>
              ✕
            </Button>
          </div>
          <ScreenshotUpload onUploadComplete={handleUploadComplete} />
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {questions.map((question) => (
          <QuestionCard
            key={question.id}
            {...question}
            isSelected={selectedQuestionId === question.id}
            onSelect={() => handleQuestionSelect(question.id)}
            onAnswer={handleQuestionAnswer}
            onOtherClick={handleOtherClick}
          />
        ))}
      </div>

      <div className="p-4 border-t border-border">
        <div className="relative">
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onFocus={() => setIsInputFocused(true)}
            onBlur={() => setIsInputFocused(false)}
            placeholder={selectedQuestionId ? "Type your answer..." : "Ask about your screenshots..."}
            className="w-full pr-12 bg-gradient-to-r from-white to-gray-50 border-2 border-primary/30 focus:border-primary/60 shadow-lg focus:shadow-xl transition-all duration-300 placeholder:text-gray-500 ring-2 ring-primary/10 focus:ring-primary/20"
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                handleSendAnswer()
              }
            }}
          />
          <Button
            size="icon"
            variant="ghost"
            className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 hover:bg-primary/10"
            onClick={handleSendAnswer}
          >
            {selectedQuestionId || message.trim() ? (
              <Send className="w-4 h-4 text-primary" />
            ) : (
              <Search className="w-4 h-4 text-primary" />
            )}
          </Button>
        </div>
      </div>

      <Dialog open={showQuestionsHistory} onOpenChange={setShowQuestionsHistory}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-primary" />
              Questions History
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-gray-600">Total answered questions: {answeredQuestionsHistory.length}</div>
            <div className="max-h-60 overflow-y-auto space-y-2">
              {answeredQuestionsHistory.map((item) => (
                <div key={item.id} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex gap-3">
                    <img
                      src={item.screenshot || "/placeholder.svg"}
                      alt="Screenshot"
                      className="w-12 h-16 object-cover rounded border flex-shrink-0"
                    />
                    <div className="flex-1">
                      <div className="font-medium text-gray-900 text-sm">{item.question}</div>
                      <div className="text-sm text-primary mt-1">Answer: {item.answer}</div>
                      <div className="text-xs text-gray-500 mt-1">Answered {item.answeredAt}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
