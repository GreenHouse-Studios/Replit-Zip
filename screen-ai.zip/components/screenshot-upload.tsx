"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Upload, Camera, Check } from "lucide-react"
import { ScreenshotProcessor } from "@/lib/screenshot-processor"

interface ScreenshotUploadProps {
  onUploadComplete?: (screenshotId: string) => void
}

export function ScreenshotUpload({ onUploadComplete }: ScreenshotUploadProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({})
  const [uploadedFiles, setUploadedFiles] = useState<{ [key: string]: string }>({})
  const fileInputRef = useRef<HTMLInputElement>(null)
  const processor = ScreenshotProcessor.getInstance()

  const handleFileSelect = (files: FileList | null) => {
    if (!files) return

    Array.from(files).forEach(async (file) => {
      if (!file.type.startsWith("image/")) return

      const fileId = `${file.name}-${Date.now()}`

      // Simulate upload progress
      setUploadProgress((prev) => ({ ...prev, [fileId]: 0 }))

      for (let progress = 0; progress <= 100; progress += 10) {
        await new Promise((resolve) => setTimeout(resolve, 100))
        setUploadProgress((prev) => ({ ...prev, [fileId]: progress }))
      }

      // Add to processor
      const screenshotId = await processor.addScreenshot(file)

      setUploadedFiles((prev) => ({ ...prev, [fileId]: screenshotId }))
      onUploadComplete?.(screenshotId)

      // Clean up progress after delay
      setTimeout(() => {
        setUploadProgress((prev) => {
          const newProgress = { ...prev }
          delete newProgress[fileId]
          return newProgress
        })
        setUploadedFiles((prev) => {
          const newFiles = { ...prev }
          delete newFiles[fileId]
          return newFiles
        })
      }, 2000)
    })
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    handleFileSelect(e.dataTransfer.files)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  return (
    <div className="space-y-4">
      <Card
        className={`p-6 border-2 border-dashed transition-colors cursor-pointer ${
          isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/25 hover:border-muted-foreground/50"
        }`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
      >
        <div className="flex flex-col items-center gap-4 text-center">
          <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
            <Upload className="w-6 h-6 text-muted-foreground" />
          </div>

          <div>
            <h3 className="font-medium mb-1">Upload Screenshots</h3>
            <p className="text-sm text-muted-foreground">Drag and drop images here, or click to select files</p>
          </div>

          <div className="flex gap-2">
            <Button size="sm" variant="outline">
              <Camera className="w-4 h-4 mr-2" />
              Take Screenshot
            </Button>
            <Button size="sm">
              <Upload className="w-4 h-4 mr-2" />
              Browse Files
            </Button>
          </div>
        </div>
      </Card>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => handleFileSelect(e.target.files)}
      />

      {/* Upload Progress */}
      {Object.keys(uploadProgress).length > 0 && (
        <div className="space-y-2">
          {Object.entries(uploadProgress).map(([fileId, progress]) => {
            const fileName = fileId.split("-")[0]
            const isComplete = uploadedFiles[fileId]

            return (
              <Card key={fileId} className="p-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded bg-muted flex items-center justify-center flex-shrink-0">
                    {isComplete ? (
                      <Check className="w-4 h-4 text-green-600" />
                    ) : (
                      <Camera className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{fileName}</p>
                    <Progress value={progress} className="h-1 mt-1" />
                  </div>

                  <div className="text-xs text-muted-foreground">{isComplete ? "Processing..." : `${progress}%`}</div>
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
