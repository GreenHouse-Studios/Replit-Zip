"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Bell, Check, X, Settings, Camera, RefreshCw } from "lucide-react"

interface AppNotification {
  id: string
  title: string
  message: string
  type: "screenshot" | "task" | "system" | "subscription"
  timestamp: Date
  read: boolean
  actions?: Array<{ label: string; action: string }>
}

export function NotificationCenter() {
  const [notifications, setNotifications] = useState<AppNotification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)

  useEffect(() => {
    // Load notifications from localStorage
    loadNotifications()

    // Listen for new notifications
    const handleNewNotification = (event: CustomEvent) => {
      addNotification(event.detail)
    }

    window.addEventListener("new-notification" as any, handleNewNotification)

    // Simulate some initial notifications
    setTimeout(() => {
      addNotification({
        title: "Welcome to Screen AI",
        message: "Background screenshot detection is now active",
        type: "system",
      })
    }, 3000)

    return () => {
      window.removeEventListener("new-notification" as any, handleNewNotification)
    }
  }, [])

  const loadNotifications = () => {
    const saved = localStorage.getItem("app_notifications")
    if (saved) {
      const parsed = JSON.parse(saved).map((n: any) => ({
        ...n,
        timestamp: new Date(n.timestamp),
      }))
      setNotifications(parsed)
      setUnreadCount(parsed.filter((n: AppNotification) => !n.read).length)
    }
  }

  const saveNotifications = (newNotifications: AppNotification[]) => {
    localStorage.setItem("app_notifications", JSON.stringify(newNotifications))
    setNotifications(newNotifications)
    setUnreadCount(newNotifications.filter((n) => !n.read).length)
  }

  const addNotification = (data: Partial<AppNotification>) => {
    const notification: AppNotification = {
      id: Math.random().toString(36).substr(2, 9),
      title: data.title || "Notification",
      message: data.message || "",
      type: data.type || "system",
      timestamp: new Date(),
      read: false,
      actions: data.actions,
    }

    const updated = [notification, ...notifications].slice(0, 50) // Keep last 50
    saveNotifications(updated)
  }

  const markAsRead = (id: string) => {
    const updated = notifications.map((n) => (n.id === id ? { ...n, read: true } : n))
    saveNotifications(updated)
  }

  const markAllAsRead = () => {
    const updated = notifications.map((n) => ({ ...n, read: true }))
    saveNotifications(updated)
  }

  const deleteNotification = (id: string) => {
    const updated = notifications.filter((n) => n.id !== id)
    saveNotifications(updated)
  }

  const clearAll = () => {
    saveNotifications([])
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "screenshot":
        return <Camera className="w-4 h-4 text-blue-500" />
      case "task":
        return <Check className="w-4 h-4 text-green-500" />
      case "system":
        return <Settings className="w-4 h-4 text-gray-500" />
      case "subscription":
        return <RefreshCw className="w-4 h-4 text-purple-500" />
      default:
        return <Bell className="w-4 h-4" />
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Notifications
              {unreadCount > 0 && (
                <Badge variant="destructive" className="text-xs">
                  {unreadCount}
                </Badge>
              )}
            </CardTitle>
            <CardDescription>Recent app activity and updates</CardDescription>
          </div>
          <div className="flex gap-2">
            {unreadCount > 0 && (
              <Button size="sm" variant="outline" onClick={markAllAsRead}>
                Mark All Read
              </Button>
            )}
            <Button size="sm" variant="outline" onClick={clearAll}>
              Clear All
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {notifications.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>No notifications yet</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={`p-3 rounded-lg border transition-all ${
                  notification.read ? "bg-muted/30" : "bg-muted/70 border-blue-200 dark:border-blue-800"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">{getNotificationIcon(notification.type)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-sm font-medium">{notification.title}</h4>
                      {!notification.read && <div className="w-2 h-2 bg-blue-500 rounded-full" />}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">{notification.timestamp.toLocaleString()}</span>
                      <div className="flex gap-1">
                        {!notification.read && (
                          <Button size="sm" variant="ghost" onClick={() => markAsRead(notification.id)}>
                            <Check className="w-3 h-3" />
                          </Button>
                        )}
                        <Button size="sm" variant="ghost" onClick={() => deleteNotification(notification.id)}>
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    {notification.actions && (
                      <div className="flex gap-2 mt-2">
                        {notification.actions.map((action, idx) => (
                          <Button key={idx} size="sm" variant="outline">
                            {action.label}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
