"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Activity, Clock, CheckCircle } from "lucide-react"
import { ScreenshotProcessor } from "@/lib/screenshot-processor"

export function ProcessingStatus() {
  const [status, setStatus] = useState({
    isProcessing: false,
    queueLength: 0,
    totalScreenshots: 0,
    processedScreenshots: 0,
  })

  const processor = ScreenshotProcessor.getInstance()

  useEffect(() => {
    const updateStatus = () => {
      setStatus(processor.getProcessingStatus())
    }

    // Update status initially
    updateStatus()

    // Update status periodically
    const interval = setInterval(updateStatus, 1000)

    // Listen for processing events
    const handleScreenshotProcessed = () => {
      updateStatus()
    }

    window.addEventListener("screenshotProcessed", handleScreenshotProcessed)

    return () => {
      clearInterval(interval)
      window.removeEventListener("screenshotProcessed", handleScreenshotProcessed)
    }
  }, [])

  const progressPercentage =
    status.totalScreenshots > 0 ? (status.processedScreenshots / status.totalScreenshots) * 100 : 0

  return (
    <Card className="p-4">
      <div className="flex items-center gap-3 mb-3">
        <div className="flex items-center gap-2">
          {status.isProcessing ? (
            <Activity className="w-4 h-4 text-blue-500 animate-pulse" />
          ) : (
            <CheckCircle className="w-4 h-4 text-green-500" />
          )}
          <h3 className="font-medium">Processing Status</h3>
        </div>

        <Badge variant={status.isProcessing ? "default" : "secondary"}>{status.isProcessing ? "Active" : "Idle"}</Badge>
      </div>

      <div className="space-y-3">
        <div>
          <div className="flex items-center justify-between text-sm mb-1">
            <span>Overall Progress</span>
            <span>
              {status.processedScreenshots}/{status.totalScreenshots}
            </span>
          </div>
          <Progress value={progressPercentage} className="h-2" />
        </div>

        <div className="grid grid-cols-3 gap-3 text-center">
          <div>
            <div className="text-lg font-bold">{status.totalScreenshots}</div>
            <div className="text-xs text-muted-foreground">Total</div>
          </div>
          <div>
            <div className="text-lg font-bold text-green-600">{status.processedScreenshots}</div>
            <div className="text-xs text-muted-foreground">Processed</div>
          </div>
          <div>
            <div className="text-lg font-bold text-blue-600">{status.queueLength}</div>
            <div className="text-xs text-muted-foreground">In Queue</div>
          </div>
        </div>

        {status.isProcessing && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>Processing screenshots in background...</span>
          </div>
        )}
      </div>
    </Card>
  )
}
