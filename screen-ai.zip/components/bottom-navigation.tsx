"use client"

import { HomeIcon, ChatIcon, ShotIcon } from "./ui/custom-icons"

interface BottomNavigationProps {
  activeTab: "home" | "chat" | "shot"
  onTabChange: (tab: "home" | "chat" | "shot") => void
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: "home" as const, label: "home", icon: HomeIcon },
    { id: "chat" as const, label: "chat", icon: ChatIcon },
    { id: "shot" as const, label: "shot", icon: ShotIcon },
  ]

  return (
    <div className="glass border-t border-white/20 backdrop-blur-xl">
      <div className="flex">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const isActive = activeTab === tab.id

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex-1 flex flex-col items-center py-4 px-4 interactive relative group ${
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {/* Active indicator */}
              {isActive && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-8 h-1 bg-gradient-primary rounded-full animate-scale-in" />
              )}

              <div className="relative">
                <Icon
                  size={28}
                  className={`transition-all duration-300 ${
                    isActive ? "drop-shadow-lg scale-110" : "group-hover:scale-105"
                  }`}
                />

                {/* Floating badge for home tab */}
                {tab.id === "home" && (
                  <div className="absolute -top-2 -right-2 w-4 h-4 bg-gradient-to-r from-accent to-orange-400 rounded-full border-2 border-white shadow-lg animate-float" />
                )}
              </div>

              <span
                className={`text-xs mt-2 font-medium transition-all duration-300 ${
                  isActive ? "font-bold text-primary" : "group-hover:text-foreground"
                }`}
              >
                {tab.label}
              </span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
