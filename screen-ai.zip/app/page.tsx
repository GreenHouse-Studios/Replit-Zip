"use client"

import { useState } from "react"
import { HomeTab } from "@/components/home-tab"
import { ChatTab } from "@/components/chat-tab"
import { ShotTab } from "@/components/shot-tab"
import { BottomNavigation } from "@/components/bottom-navigation"
import { AuthProvider } from "@/components/auth/auth-provider"

export default function ScreenAI() {
  const [activeTab, setActiveTab] = useState<"home" | "chat" | "shot">("home")

  return (
    <AuthProvider>
      <div className="min-h-screen bg-background flex flex-col max-w-sm mx-auto border-x border-border">
        {/* Status Bar Simulation */}
        <div className="h-6 bg-background border-b border-border flex items-center justify-between px-4 text-xs text-muted-foreground">
          <span>9:41</span>
          <span>Screen AI</span>
          <span>100%</span>
        </div>

        {/* Main Content */}
        <div className="text-xl font-bold leading-none mb-1 text-black">
          {activeTab === "home" && <HomeTab />}
          {activeTab === "chat" && <ChatTab />}
          {activeTab === "shot" && <ShotTab />}
        </div>

        {/* Bottom Navigation */}
        <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>
    </AuthProvider>
  )
}
