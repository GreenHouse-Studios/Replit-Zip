import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import type { NextRequest } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { imageData, extractedText, userContext, isPro } = await request.json()

    if (!imageData && !extractedText) {
      return new Response("Image data or extracted text is required", { status: 400 })
    }

    const model = isPro ? "gpt-4o" : "gpt-4o-mini"

    const prompt = `Analyze this screenshot and generate actionable tasks:

${extractedText ? `Extracted Text: ${extractedText}` : ""}
${userContext ? `User Context: ${JSON.stringify(userContext, null, 2)}` : ""}

Please:
1. Identify the main content/purpose of this screenshot
2. Generate 1-3 specific, actionable tasks based on the content
3. Classify the urgency level (urgent, daily, normal)
4. Suggest a completion timeframe
5. Identify any important links or resources

Return a JSON response with this structure:
{
  "tasks": [
    {
      "title": "Task title",
      "description": "Brief description",
      "urgency": "urgent|daily|normal",
      "estimatedTime": "time in minutes",
      "dueDate": "suggested due date",
      "resources": ["link1", "link2"],
      "category": "work|personal|education|entertainment"
    }
  ],
  "classification": "screenshot category",
  "summary": "brief summary of screenshot content"
}

Make sure to return valid JSON only.`

    const result = await generateText({
      model: openai(model),
      prompt: prompt,
      temperature: 0.3,
      maxTokens: isPro ? 800 : 400,
    })

    try {
      const parsedResult = JSON.parse(result.text)
      return Response.json(parsedResult)
    } catch (parseError) {
      console.error("JSON parsing failed:", parseError)
      // Fallback if JSON parsing fails
      return Response.json({
        tasks: [
          {
            title: "Review Screenshot",
            description: result.text.substring(0, 100) + "...",
            urgency: "normal",
            estimatedTime: "5 minutes",
            dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
            resources: [],
            category: "personal",
          },
        ],
        classification: "general",
        summary: "Screenshot processed",
      })
    }
  } catch (error) {
    console.error("Error processing screenshot:", error)
    return new Response("Failed to process screenshot", { status: 500 })
  }
}
