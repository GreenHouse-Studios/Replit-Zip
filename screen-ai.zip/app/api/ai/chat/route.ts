import { streamText } from "ai"
import { openai } from "@ai-sdk/openai"
import type { NextRequest } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { messages, screenshot, userContext, isPro } = await request.json()

    if (!messages || messages.length === 0) {
      return new Response("Messages are required", { status: 400 })
    }

    const model = isPro ? "gpt-4o" : "gpt-4o-mini"

    // Build context-aware system prompt
    const systemPrompt = `You are Screen AI, an intelligent assistant that helps users understand and act on their screenshots. 

${userContext ? `User Context: ${JSON.stringify(userContext, null, 2)}` : ""}

${screenshot ? `Current Screenshot Context: The user is asking about a screenshot. Analyze the content and provide helpful insights.` : ""}

Guidelines:
- Be concise and actionable
- Focus on practical next steps
- If analyzing a screenshot, identify key information and suggest tasks
- Learn from user patterns to provide better recommendations
- For Pro users, provide more detailed analysis and advanced features
- Always respond in a helpful, professional tone`

    const result = streamText({
      model: openai(model),
      messages: messages,
      system: systemPrompt,
      temperature: 0.7,
      maxTokens: isPro ? 1000 : 500,
    })

    return result.toTextStreamResponse()
  } catch (error) {
    console.error("Error in AI chat:", error)
    return new Response("Failed to generate AI response", { status: 500 })
  }
}
