// Background service for handling screenshot detection, processing, and notifications
// In a real React Native app, this would use native background tasks

export interface BackgroundTask {
  id: string
  type: "screenshot_detection" | "processing" | "cleanup" | "sync" | "analytics"
  status: "pending" | "running" | "completed" | "failed"
  createdAt: Date
  completedAt?: Date
  data?: any
  error?: string
}

export interface NotificationPayload {
  title: string
  body: string
  data?: Record<string, any>
  actions?: Array<{ action: string; title: string }>
}

class BackgroundServiceManager {
  private isRunning = false
  private tasks: BackgroundTask[] = []
  private intervals: NodeJS.Timeout[] = []
  private listeners: Array<(task: BackgroundTask) => void> = []

  // Start background services
  start() {
    if (this.isRunning) return

    this.isRunning = true
    console.log("🔄 Background services started")

    // Screenshot detection simulation (every 30 seconds)
    const screenshotDetection = setInterval(() => {
      this.scheduleTask("screenshot_detection", {})
    }, 30000)

    // Processing queue check (every 10 seconds)
    const processingCheck = setInterval(() => {
      this.processQueue()
    }, 10000)

    // Cleanup old data (every hour)
    const cleanup = setInterval(() => {
      this.scheduleTask("cleanup", {})
    }, 3600000)

    // Sync with Firebase (every 5 minutes)
    const sync = setInterval(() => {
      this.scheduleTask("sync", {})
    }, 300000)

    // Analytics tracking (every 15 minutes)
    const analytics = setInterval(() => {
      this.scheduleTask("analytics", {})
    }, 900000)

    this.intervals = [screenshotDetection, processingCheck, cleanup, sync, analytics]

    // Request notification permission
    this.requestNotificationPermission()
  }

  // Stop background services
  stop() {
    if (!this.isRunning) return

    this.isRunning = false
    this.intervals.forEach(clearInterval)
    this.intervals = []
    console.log("⏹️ Background services stopped")
  }

  // Schedule a background task
  private scheduleTask(type: BackgroundTask["type"], data: any): string {
    const task: BackgroundTask = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      status: "pending",
      createdAt: new Date(),
      data,
    }

    this.tasks.push(task)
    this.notifyListeners(task)
    return task.id
  }

  // Process pending tasks
  private async processQueue() {
    const pendingTasks = this.tasks.filter((task) => task.status === "pending")

    for (const task of pendingTasks.slice(0, 3)) {
      // Process max 3 tasks at once
      await this.executeTask(task)
    }
  }

  // Execute a specific task
  private async executeTask(task: BackgroundTask) {
    task.status = "running"
    this.notifyListeners(task)

    try {
      switch (task.type) {
        case "screenshot_detection":
          await this.handleScreenshotDetection(task)
          break
        case "processing":
          await this.handleScreenshotProcessing(task)
          break
        case "cleanup":
          await this.handleCleanup(task)
          break
        case "sync":
          await this.handleSync(task)
          break
        case "analytics":
          await this.handleAnalytics(task)
          break
      }

      task.status = "completed"
      task.completedAt = new Date()
    } catch (error) {
      task.status = "failed"
      task.error = (error as Error).message
      console.error(`Background task ${task.type} failed:`, error)
    }

    this.notifyListeners(task)
  }

  // Handle screenshot detection
  private async handleScreenshotDetection(task: BackgroundTask) {
    // Simulate screenshot detection
    const hasNewScreenshot = Math.random() < 0.3 // 30% chance of new screenshot

    if (hasNewScreenshot) {
      console.log("📸 New screenshot detected")

      // Schedule processing task
      this.scheduleTask("processing", {
        screenshotId: `screenshot_${Date.now()}`,
        source: "background_detection",
      })

      // Send notification
      await this.sendNotification({
        title: "New Screenshot Detected",
        body: "Processing your screenshot to create tasks...",
        data: { type: "screenshot_detected" },
      })
    }
  }

  // Handle screenshot processing
  private async handleScreenshotProcessing(task: BackgroundTask) {
    const { screenshotId } = task.data

    // Simulate AI processing delay
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Simulate task generation
    const generatedTasks = Math.floor(Math.random() * 3) + 1

    console.log(`🤖 Processed screenshot ${screenshotId}, generated ${generatedTasks} tasks`)

    // Send completion notification
    await this.sendNotification({
      title: "Screenshot Processed",
      body: `Generated ${generatedTasks} new task${generatedTasks > 1 ? "s" : ""} from your screenshot`,
      data: {
        type: "processing_complete",
        screenshotId,
        taskCount: generatedTasks,
      },
      actions: [
        { action: "view_tasks", title: "View Tasks" },
        { action: "dismiss", title: "Dismiss" },
      ],
    })

    // Update local storage with new tasks
    this.updateLocalTasks(generatedTasks)
  }

  // Handle cleanup of old data
  private async handleCleanup(task: BackgroundTask) {
    console.log("🧹 Running cleanup tasks")

    // Clean up old completed tasks
    this.tasks = this.tasks.filter((t) => {
      const isOld = Date.now() - t.createdAt.getTime() > 24 * 60 * 60 * 1000 // 24 hours
      return !(t.status === "completed" && isOld)
    })

    // Clean up old screenshots from localStorage (simulate)
    const screenshots = JSON.parse(localStorage.getItem("processed_screenshots") || "[]")
    const recentScreenshots = screenshots.filter((s: any) => {
      return Date.now() - new Date(s.createdAt).getTime() < 7 * 24 * 60 * 60 * 1000 // 7 days
    })

    localStorage.setItem("processed_screenshots", JSON.stringify(recentScreenshots))
  }

  // Handle sync with Firebase
  private async handleSync(task: BackgroundTask) {
    console.log("☁️ Syncing with Firebase")

    // Simulate sync operations
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Update sync timestamp
    localStorage.setItem("last_sync", new Date().toISOString())
  }

  // Handle analytics tracking
  private async handleAnalytics(task: BackgroundTask) {
    console.log("📊 Tracking analytics")

    const analytics = {
      sessionTime: Date.now() - (Number.parseInt(localStorage.getItem("session_start") || "0") || Date.now()),
      screenshotsProcessed: Number.parseInt(localStorage.getItem("screenshots_processed_today") || "0"),
      tasksCompleted: Number.parseInt(localStorage.getItem("tasks_completed_today") || "0"),
      timestamp: new Date().toISOString(),
    }

    // Store analytics data
    const existingAnalytics = JSON.parse(localStorage.getItem("analytics_data") || "[]")
    existingAnalytics.push(analytics)

    // Keep only last 30 days
    const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000
    const recentAnalytics = existingAnalytics.filter((a: any) => new Date(a.timestamp).getTime() > thirtyDaysAgo)

    localStorage.setItem("analytics_data", JSON.stringify(recentAnalytics))
  }

  // Request notification permission
  private async requestNotificationPermission() {
    if ("Notification" in window) {
      const permission = await Notification.requestPermission()
      console.log("🔔 Notification permission:", permission)
    }
  }

  // Send push notification
  private async sendNotification(payload: NotificationPayload) {
    if ("Notification" in window && Notification.permission === "granted") {
      const notification = new Notification(payload.title, {
        body: payload.body,
        icon: "/favicon.ico",
        badge: "/favicon.ico",
        data: payload.data,
        actions: payload.actions as any,
        requireInteraction: false,
        silent: false,
      })

      // Auto-close after 5 seconds
      setTimeout(() => notification.close(), 5000)

      // Handle notification clicks
      notification.onclick = () => {
        window.focus()
        notification.close()

        // Handle different notification types
        if (payload.data?.type === "processing_complete") {
          // Navigate to home tab to show new tasks
          window.dispatchEvent(new CustomEvent("navigate-to-home"))
        }
      }
    }
  }

  // Update local task count
  private updateLocalTasks(newTaskCount: number) {
    const currentCount = Number.parseInt(localStorage.getItem("total_tasks") || "0")
    localStorage.setItem("total_tasks", (currentCount + newTaskCount).toString())

    const todayCount = Number.parseInt(localStorage.getItem("tasks_created_today") || "0")
    localStorage.setItem("tasks_created_today", (todayCount + newTaskCount).toString())
  }

  // Add task listener
  onTaskUpdate(callback: (task: BackgroundTask) => void) {
    this.listeners.push(callback)
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback)
    }
  }

  // Notify listeners
  private notifyListeners(task: BackgroundTask) {
    this.listeners.forEach((listener) => listener(task))
  }

  // Get task history
  getTaskHistory(): BackgroundTask[] {
    return [...this.tasks].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
  }

  // Get service status
  getStatus() {
    return {
      isRunning: this.isRunning,
      pendingTasks: this.tasks.filter((t) => t.status === "pending").length,
      runningTasks: this.tasks.filter((t) => t.status === "running").length,
      completedTasks: this.tasks.filter((t) => t.status === "completed").length,
      failedTasks: this.tasks.filter((t) => t.status === "failed").length,
    }
  }

  // Manual screenshot processing trigger
  processScreenshot(screenshotData: string, extractedText: string) {
    return this.scheduleTask("processing", {
      screenshotId: `manual_${Date.now()}`,
      screenshotData,
      extractedText,
      source: "manual_upload",
    })
  }
}

// Singleton instance
export const backgroundService = new BackgroundServiceManager()

// Auto-start when module loads (in a real app, this would be handled by the native layer)
if (typeof window !== "undefined") {
  // Start services after a short delay
  setTimeout(() => {
    backgroundService.start()
    localStorage.setItem("session_start", Date.now().toString())
  }, 2000)

  // Stop services when page unloads
  window.addEventListener("beforeunload", () => {
    backgroundService.stop()
  })
}
