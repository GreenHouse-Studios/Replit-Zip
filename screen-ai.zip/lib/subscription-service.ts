import { firebaseService } from "./firebase-service"

export interface SubscriptionPlan {
  id: string
  name: string
  price: number
  interval: "monthly" | "yearly"
  features: string[]
  limits: {
    screenshotsPerMonth: number
    aiRequestsPerDay: number
    cloudStorageDays: number
    exportFormats: string[]
  }
}

export interface SubscriptionStatus {
  isActive: boolean
  plan: SubscriptionPlan
  currentPeriodEnd: Date
  cancelAtPeriodEnd: boolean
  trialEnd?: Date
  isTrialing: boolean
}

export const SUBSCRIPTION_PLANS: Record<string, SubscriptionPlan> = {
  free: {
    id: "free",
    name: "Free",
    price: 0,
    interval: "monthly",
    features: [
      "Basic AI task creation",
      "Screenshot folder organization",
      "Delete processed screenshots",
      "Up to 50 screenshots/month",
      "Basic AI chat (GPT-4o-mini)",
    ],
    limits: {
      screenshotsPerMonth: 50,
      aiRequestsPerDay: 10,
      cloudStorageDays: 0,
      exportFormats: [],
    },
  },
  pro_monthly: {
    id: "pro_monthly",
    name: "Screen AI Pro",
    price: 9.99,
    interval: "monthly",
    features: [
      "Advanced AI processing (GPT-5)",
      "Unlimited screenshots",
      "Export to Notes apps",
      "Auto-download images from screenshots",
      "Cloud storage for 30 days",
      "Create offline PDFs",
      "Advanced analytics",
      "Priority support",
    ],
    limits: {
      screenshotsPerMonth: -1, // unlimited
      aiRequestsPerDay: 100,
      cloudStorageDays: 30,
      exportFormats: ["pdf", "csv", "notes"],
    },
  },
  pro_yearly: {
    id: "pro_yearly",
    name: "Screen AI Pro (Yearly)",
    price: 99.99,
    interval: "yearly",
    features: [
      "Advanced AI processing (GPT-5)",
      "Unlimited screenshots",
      "Export to Notes apps",
      "Auto-download images from screenshots",
      "Cloud storage for 30 days",
      "Create offline PDFs",
      "Advanced analytics",
      "Priority support",
      "2 months free",
    ],
    limits: {
      screenshotsPerMonth: -1,
      aiRequestsPerDay: 100,
      cloudStorageDays: 30,
      exportFormats: ["pdf", "csv", "notes"],
    },
  },
}

export class SubscriptionService {
  // Check if user has access to a specific feature
  static hasFeature(userSubscription: SubscriptionStatus | null, feature: string): boolean {
    if (!userSubscription || !userSubscription.isActive) {
      return SUBSCRIPTION_PLANS.free.features.includes(feature)
    }

    return userSubscription.plan.features.includes(feature)
  }

  // Check if user is within usage limits
  static checkLimit(
    userSubscription: SubscriptionStatus | null,
    limitType: keyof SubscriptionPlan["limits"],
    currentUsage: number,
  ): boolean {
    const plan = userSubscription?.isActive ? userSubscription.plan : SUBSCRIPTION_PLANS.free
    const limit = plan.limits[limitType]

    if (typeof limit === "number") {
      return limit === -1 || currentUsage < limit
    }

    return true
  }

  // Start free trial
  static async startFreeTrial(userId: string): Promise<void> {
    const trialEnd = new Date()
    trialEnd.setDate(trialEnd.getDate() + 31) // 31 days trial

    await firebaseService.updateSubscription(userId, true, "pro_trial", trialEnd)
    await firebaseService.logAnalyticsEvent("trial_started", { userId })
  }

  // Simulate payment processing
  static async processPayment(
    userId: string,
    planId: string,
    paymentMethod: "card" | "paypal" | "apple_pay" | "google_pay",
  ): Promise<{ success: boolean; subscriptionId?: string; error?: string }> {
    try {
      // Simulate payment processing delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Simulate 95% success rate
      if (Math.random() < 0.95) {
        const plan = SUBSCRIPTION_PLANS[planId]
        if (!plan) {
          throw new Error("Invalid plan")
        }

        const subscriptionId = `sub_${Math.random().toString(36).substr(2, 9)}`
        const currentPeriodEnd = new Date()

        if (plan.interval === "monthly") {
          currentPeriodEnd.setMonth(currentPeriodEnd.getMonth() + 1)
        } else {
          currentPeriodEnd.setFullYear(currentPeriodEnd.getFullYear() + 1)
        }

        await firebaseService.updateSubscription(userId, true, planId, currentPeriodEnd)

        await firebaseService.logAnalyticsEvent("subscription_created", {
          userId,
          planId,
          paymentMethod,
          amount: plan.price,
        })

        return { success: true, subscriptionId }
      } else {
        throw new Error("Payment failed")
      }
    } catch (error) {
      return { success: false, error: (error as Error).message }
    }
  }

  // Cancel subscription
  static async cancelSubscription(userId: string): Promise<void> {
    // In a real app, this would call the payment processor API
    await firebaseService.updateSubscription(userId, false, "free")
    await firebaseService.logAnalyticsEvent("subscription_cancelled", { userId })
  }

  // Get current subscription status
  static async getSubscriptionStatus(userId: string): Promise<SubscriptionStatus> {
    const userProfile = await firebaseService.getUserProfile(userId)

    if (!userProfile || !userProfile.subscription.isPro) {
      return {
        isActive: false,
        plan: SUBSCRIPTION_PLANS.free,
        currentPeriodEnd: new Date(),
        cancelAtPeriodEnd: false,
        isTrialing: false,
      }
    }

    const plan = SUBSCRIPTION_PLANS[userProfile.subscription.plan] || SUBSCRIPTION_PLANS.free
    const isTrialing = userProfile.subscription.plan === "pro_trial"
    const currentPeriodEnd = userProfile.subscription.expiresAt || new Date()

    return {
      isActive: true,
      plan,
      currentPeriodEnd,
      cancelAtPeriodEnd: false,
      trialEnd: isTrialing ? currentPeriodEnd : undefined,
      isTrialing,
    }
  }
}
