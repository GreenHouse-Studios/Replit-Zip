"use client"

export interface Screenshot {
  id: string
  filename: string
  url: string
  timestamp: Date
  processed: boolean
  extractedText?: string
  classification?: ScreenshotType
  tasks?: Task[]
  folder?: string
  isImportant?: boolean
}

export interface Task {
  id: string
  title: string
  description: string
  isUrgent: boolean
  isDaily: boolean
  dueDate?: string
  links: string[]
  screenshotId: string
  completed: boolean
}

export type ScreenshotType =
  | "personal"
  | "school"
  | "work"
  | "social"
  | "shopping"
  | "entertainment"
  | "productivity"
  | "other"

export class ScreenshotProcessor {
  private static instance: ScreenshotProcessor
  private screenshots: Screenshot[] = []
  private processingQueue: string[] = []
  private isProcessing = false

  static getInstance(): ScreenshotProcessor {
    if (!ScreenshotProcessor.instance) {
      ScreenshotProcessor.instance = new ScreenshotProcessor()
    }
    return ScreenshotProcessor.instance
  }

  // Simulate OCR text extraction
  async extractText(imageUrl: string): Promise<string> {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Mock OCR results based on image type
    const mockTexts = [
      "Apply to top 5 colleges - they are only 5 in USA",
      "Watch WVFRR.fm Podcast - you haven't watched this episode",
      "Meeting at 3 PM tomorrow with the team",
      "Buy groceries: milk, bread, eggs, apples",
      "Call dentist to schedule appointment",
      "Review quarterly report by Friday",
      "Book flight tickets for vacation",
    ]

    return mockTexts[Math.floor(Math.random() * mockTexts.length)]
  }

  // Classify screenshot type based on extracted text
  classifyScreenshot(extractedText: string): ScreenshotType {
    const text = extractedText.toLowerCase()

    if (text.includes("college") || text.includes("school") || text.includes("assignment")) {
      return "school"
    }
    if (text.includes("meeting") || text.includes("work") || text.includes("report")) {
      return "work"
    }
    if (text.includes("buy") || text.includes("shop") || text.includes("price")) {
      return "shopping"
    }
    if (text.includes("watch") || text.includes("podcast") || text.includes("video")) {
      return "entertainment"
    }
    if (text.includes("call") || text.includes("appointment") || text.includes("schedule")) {
      return "productivity"
    }

    return "other"
  }

  // Generate tasks from extracted text
  generateTasks(screenshot: Screenshot): Task[] {
    if (!screenshot.extractedText) return []

    const text = screenshot.extractedText.toLowerCase()
    const tasks: Task[] = []

    // Simple task generation logic
    if (text.includes("apply") || text.includes("deadline")) {
      tasks.push({
        id: `task-${Date.now()}-1`,
        title: this.extractTitle(screenshot.extractedText),
        description: screenshot.extractedText,
        isUrgent: text.includes("deadline") || text.includes("urgent"),
        isDaily: false,
        dueDate: this.extractDueDate(screenshot.extractedText),
        links: this.extractLinks(screenshot.extractedText),
        screenshotId: screenshot.id,
        completed: false,
      })
    }

    if (text.includes("watch") || text.includes("listen")) {
      tasks.push({
        id: `task-${Date.now()}-2`,
        title: this.extractTitle(screenshot.extractedText),
        description: screenshot.extractedText,
        isUrgent: false,
        isDaily: true,
        links: this.extractLinks(screenshot.extractedText),
        screenshotId: screenshot.id,
        completed: false,
      })
    }

    if (text.includes("call") || text.includes("schedule") || text.includes("appointment")) {
      tasks.push({
        id: `task-${Date.now()}-3`,
        title: this.extractTitle(screenshot.extractedText),
        description: screenshot.extractedText,
        isUrgent: true,
        isDaily: false,
        links: [],
        screenshotId: screenshot.id,
        completed: false,
      })
    }

    return tasks
  }

  private extractTitle(text: string): string {
    // Extract first meaningful sentence as title
    const sentences = text.split(/[.!?]/)
    return sentences[0]?.trim().substring(0, 50) || "New Task"
  }

  private extractDueDate(text: string): string | undefined {
    // Simple date extraction
    const datePatterns = [
      /\d{1,2}[./]\d{1,2}[./]\d{2,4}/,
      /\d{1,2}[./]\d{1,2}/,
      /(tomorrow|today|next week|friday|monday|tuesday|wednesday|thursday|saturday|sunday)/i,
    ]

    for (const pattern of datePatterns) {
      const match = text.match(pattern)
      if (match) return match[0]
    }

    return undefined
  }

  private extractLinks(text: string): string[] {
    const urlPattern = /(https?:\/\/[^\s]+)/g
    const matches = text.match(urlPattern)
    return matches || []
  }

  // Process a screenshot through the full pipeline
  async processScreenshot(screenshot: Screenshot): Promise<Screenshot> {
    try {
      // Extract text using OCR
      const extractedText = await this.extractText(screenshot.url)

      // Classify screenshot
      const classification = this.classifyScreenshot(extractedText)

      // Generate tasks
      const updatedScreenshot: Screenshot = {
        ...screenshot,
        extractedText,
        classification,
        processed: true,
        folder: classification,
      }

      const tasks = this.generateTasks(updatedScreenshot)
      updatedScreenshot.tasks = tasks

      return updatedScreenshot
    } catch (error) {
      console.error("Error processing screenshot:", error)
      return { ...screenshot, processed: true }
    }
  }

  // Add screenshot to processing queue
  async addScreenshot(file: File): Promise<string> {
    const id = `screenshot-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    const url = URL.createObjectURL(file)

    const screenshot: Screenshot = {
      id,
      filename: file.name,
      url,
      timestamp: new Date(),
      processed: false,
    }

    this.screenshots.push(screenshot)
    this.processingQueue.push(id)

    // Start processing if not already running
    if (!this.isProcessing) {
      this.processQueue()
    }

    return id
  }

  // Process the queue of screenshots
  private async processQueue() {
    if (this.processingQueue.length === 0) {
      this.isProcessing = false
      return
    }

    this.isProcessing = true

    while (this.processingQueue.length > 0) {
      const screenshotId = this.processingQueue.shift()!
      const screenshot = this.screenshots.find((s) => s.id === screenshotId)

      if (screenshot) {
        const processed = await this.processScreenshot(screenshot)
        const index = this.screenshots.findIndex((s) => s.id === screenshotId)
        if (index !== -1) {
          this.screenshots[index] = processed
        }

        // Notify listeners about processing completion
        this.notifyProcessingComplete(processed)
      }
    }

    this.isProcessing = false
  }

  private notifyProcessingComplete(screenshot: Screenshot) {
    // Dispatch custom event for UI updates
    window.dispatchEvent(
      new CustomEvent("screenshotProcessed", {
        detail: screenshot,
      }),
    )
  }

  // Get all screenshots
  getScreenshots(): Screenshot[] {
    return [...this.screenshots]
  }

  // Get screenshots by folder/classification
  getScreenshotsByFolder(folder: string): Screenshot[] {
    return this.screenshots.filter((s) => s.folder === folder)
  }

  // Get all tasks from processed screenshots
  getAllTasks(): Task[] {
    return this.screenshots.filter((s) => s.tasks).flatMap((s) => s.tasks!)
  }

  // Delete screenshot
  deleteScreenshot(id: string): boolean {
    const index = this.screenshots.findIndex((s) => s.id === id)
    if (index !== -1) {
      // Revoke object URL to free memory
      URL.revokeObjectURL(this.screenshots[index].url)
      this.screenshots.splice(index, 1)
      return true
    }
    return false
  }

  // Mark screenshot as important
  toggleImportant(id: string): boolean {
    const screenshot = this.screenshots.find((s) => s.id === id)
    if (screenshot) {
      screenshot.isImportant = !screenshot.isImportant
      return true
    }
    return false
  }

  // Get processing status
  getProcessingStatus() {
    return {
      isProcessing: this.isProcessing,
      queueLength: this.processingQueue.length,
      totalScreenshots: this.screenshots.length,
      processedScreenshots: this.screenshots.filter((s) => s.processed).length,
    }
  }
}
