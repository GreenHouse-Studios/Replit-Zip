export interface AIMessage {
  role: "user" | "assistant" | "system"
  content: string
  timestamp?: number
  screenshot?: string
}

export interface ProcessedTask {
  id: string
  title: string
  description: string
  urgency: "urgent" | "daily" | "normal"
  estimatedTime: string
  dueDate: string
  resources: string[]
  category: string
  completed: boolean
  createdAt: string
  screenshotId?: string
}

export interface UserContext {
  preferences: {
    workHours: string
    taskCategories: string[]
    urgencyPreferences: Record<string, number>
  }
  history: {
    commonTasks: string[]
    frequentApps: string[]
    timePatterns: Record<string, number>
  }
  subscription: {
    isPro: boolean
    features: string[]
  }
}

export class AIService {
  private userContext: UserContext | null = null

  constructor() {
    this.loadUserContext()
  }

  private loadUserContext() {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("screen-ai-context")
      if (saved) {
        this.userContext = JSON.parse(saved)
      } else {
        this.userContext = this.getDefaultContext()
      }
    }
  }

  private getDefaultContext(): UserContext {
    return {
      preferences: {
        workHours: "9-17",
        taskCategories: ["work", "personal", "education"],
        urgencyPreferences: { urgent: 1, daily: 2, normal: 3 },
      },
      history: {
        commonTasks: [],
        frequentApps: [],
        timePatterns: {},
      },
      subscription: {
        isPro: false,
        features: ["basic-processing", "task-generation"],
      },
    }
  }

  async processScreenshot(imageData: string, extractedText: string): Promise<ProcessedTask[]> {
    try {
      const response = await fetch("/api/ai/process-screenshot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageData,
          extractedText,
          userContext: this.userContext,
          isPro: this.userContext?.subscription.isPro || false,
        }),
      })

      if (!response.ok) throw new Error("Failed to process screenshot")

      const result = await response.json()

      // Convert to ProcessedTask format
      const tasks: ProcessedTask[] = result.tasks.map((task: any) => ({
        id: Math.random().toString(36).substr(2, 9),
        ...task,
        completed: false,
        createdAt: new Date().toISOString(),
        screenshotId: Math.random().toString(36).substr(2, 9),
      }))

      // Update user context based on new tasks
      this.updateUserContext(tasks)

      return tasks
    } catch (error) {
      console.error("Error processing screenshot:", error)
      return []
    }
  }

  async chatWithAI(messages: AIMessage[], useAdvancedModel = false): Promise<ReadableStream> {
    const response = await fetch("/api/ai/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: messages.map((m) => ({ role: m.role, content: m.content })),
        screenshot: messages.some((m) => m.screenshot),
        userContext: this.userContext,
        isPro: useAdvancedModel,
      }),
    })

    if (!response.ok) throw new Error("Failed to get AI response")
    return response.body!
  }

  private updateUserContext(tasks: ProcessedTask[]) {
    if (!this.userContext) return

    // Update common tasks
    tasks.forEach((task) => {
      if (!this.userContext!.history.commonTasks.includes(task.category)) {
        this.userContext!.history.commonTasks.push(task.category)
      }
    })

    // Update time patterns
    const hour = new Date().getHours()
    this.userContext.history.timePatterns[hour] = (this.userContext.history.timePatterns[hour] || 0) + 1

    // Save to localStorage
    if (typeof window !== "undefined") {
      localStorage.setItem("screen-ai-context", JSON.stringify(this.userContext))
    }
  }

  getUserContext(): UserContext | null {
    return this.userContext
  }

  updateSubscription(isPro: boolean, features: string[]) {
    if (this.userContext) {
      this.userContext.subscription = { isPro, features }
      if (typeof window !== "undefined") {
        localStorage.setItem("screen-ai-context", JSON.stringify(this.userContext))
      }
    }
  }
}

export const aiService = new AIService()
