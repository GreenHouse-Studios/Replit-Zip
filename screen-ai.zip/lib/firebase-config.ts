// Firebase configuration and initialization
// Note: In a real React Native app, this would use actual Firebase SDK

export interface FirebaseConfig {
  apiKey: string
  authDomain: string
  projectId: string
  storageBucket: string
  messagingSenderId: string
  appId: string
  measurementId: string
}

// Mock Firebase config - in production, these would be real Firebase credentials
const firebaseConfig: FirebaseConfig = {
  apiKey: "mock-api-key",
  authDomain: "screen-ai-app.firebaseapp.com",
  projectId: "screen-ai-app",
  storageBucket: "screen-ai-app.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456",
  measurementId: "G-ABCDEF123456",
}

// Mock Firebase services for web simulation
export class MockFirebaseAuth {
  private currentUser: any = null
  private listeners: ((user: any) => void)[] = []

  async signInWithEmailAndPassword(email: string, password: string) {
    // Simulate authentication
    await new Promise((resolve) => setTimeout(resolve, 1000))
    this.currentUser = {
      uid: Math.random().toString(36).substr(2, 9),
      email,
      displayName: email.split("@")[0],
      photoURL: null,
      emailVerified: true,
    }
    this.notifyListeners()
    return { user: this.currentUser }
  }

  async createUserWithEmailAndPassword(email: string, password: string) {
    await new Promise((resolve) => setTimeout(resolve, 1000))
    this.currentUser = {
      uid: Math.random().toString(36).substr(2, 9),
      email,
      displayName: email.split("@")[0],
      photoURL: null,
      emailVerified: false,
    }
    this.notifyListeners()
    return { user: this.currentUser }
  }

  async signOut() {
    this.currentUser = null
    this.notifyListeners()
  }

  onAuthStateChanged(callback: (user: any) => void) {
    this.listeners.push(callback)
    callback(this.currentUser)
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback)
    }
  }

  getCurrentUser() {
    return this.currentUser
  }

  private notifyListeners() {
    this.listeners.forEach((listener) => listener(this.currentUser))
  }
}

export class MockFirestore {
  private collections: Record<string, Record<string, any>> = {}

  collection(name: string) {
    if (!this.collections[name]) {
      this.collections[name] = {}
    }

    return {
      doc: (id?: string) => {
        const docId = id || Math.random().toString(36).substr(2, 9)
        return {
          id: docId,
          set: async (data: any) => {
            this.collections[name][docId] = { ...data, id: docId, createdAt: new Date() }
            return { id: docId }
          },
          get: async () => {
            const data = this.collections[name][docId]
            return {
              exists: !!data,
              data: () => data,
              id: docId,
            }
          },
          update: async (data: any) => {
            if (this.collections[name][docId]) {
              this.collections[name][docId] = { ...this.collections[name][docId], ...data, updatedAt: new Date() }
            }
          },
          delete: async () => {
            delete this.collections[name][docId]
          },
        }
      },
      where: (field: string, operator: string, value: any) => ({
        get: async () => {
          const docs = Object.values(this.collections[name] || {}).filter((doc) => {
            switch (operator) {
              case "==":
                return doc[field] === value
              case "!=":
                return doc[field] !== value
              case ">":
                return doc[field] > value
              case "<":
                return doc[field] < value
              case ">=":
                return doc[field] >= value
              case "<=":
                return doc[field] <= value
              case "array-contains":
                return Array.isArray(doc[field]) && doc[field].includes(value)
              default:
                return false
            }
          })
          return {
            docs: docs.map((doc) => ({
              id: doc.id,
              data: () => doc,
            })),
          }
        },
      }),
      get: async () => {
        const docs = Object.values(this.collections[name] || {})
        return {
          docs: docs.map((doc) => ({
            id: doc.id,
            data: () => doc,
          })),
        }
      },
      add: async (data: any) => {
        const id = Math.random().toString(36).substr(2, 9)
        this.collections[name][id] = { ...data, id, createdAt: new Date() }
        return { id }
      },
    }
  }
}

export class MockFirebaseStorage {
  private files: Record<string, string> = {}

  ref(path: string) {
    return {
      put: async (file: File | Blob) => {
        // Simulate file upload
        await new Promise((resolve) => setTimeout(resolve, 2000))
        const url = `https://mock-storage.com/${path}`
        this.files[path] = url
        return {
          ref: {
            getDownloadURL: async () => url,
          },
        }
      },
      getDownloadURL: async () => {
        return this.files[path] || `https://mock-storage.com/${path}`
      },
      delete: async () => {
        delete this.files[path]
      },
    }
  }
}

export class MockFirebaseAnalytics {
  logEvent(eventName: string, parameters?: Record<string, any>) {
    console.log(`Analytics Event: ${eventName}`, parameters)
  }

  setUserProperties(properties: Record<string, any>) {
    console.log("User Properties:", properties)
  }

  setUserId(userId: string) {
    console.log("User ID:", userId)
  }
}

// Initialize mock Firebase services
export const auth = new MockFirebaseAuth()
export const firestore = new MockFirestore()
export const storage = new MockFirebaseStorage()
export const analytics = new MockFirebaseAnalytics()

export default firebaseConfig
