import { auth, firestore, storage, analytics } from "./firebase-config"
import type { ProcessedTask } from "./ai-service"

export interface User {
  uid: string
  email: string
  displayName: string
  photoURL?: string
  subscription: {
    isPro: boolean
    plan: string
    expiresAt?: Date
  }
  preferences: {
    notifications: boolean
    autoDelete: boolean
    dailyGoal: number
  }
  stats: {
    totalScreenshots: number
    totalTasks: number
    completedTasks: number
    streakDays: number
  }
}

export interface Screenshot {
  id: string
  userId: string
  url: string
  thumbnailUrl: string
  extractedText: string
  classification: string
  folder: string
  processed: boolean
  createdAt: Date
  deletedAt?: Date
  metadata: {
    size: number
    dimensions: { width: number; height: number }
    source: string
  }
}

export interface TaskData extends ProcessedTask {
  userId: string
  screenshotId: string
}

export class FirebaseService {
  // Authentication methods
  async signIn(email: string, password: string) {
    try {
      const result = await auth.signInWithEmailAndPassword(email, password)
      analytics.logEvent("login", { method: "email" })
      return result.user
    } catch (error) {
      console.error("Sign in error:", error)
      throw error
    }
  }

  async signUp(email: string, password: string) {
    try {
      const result = await auth.createUserWithEmailAndPassword(email, password)

      // Create user profile
      await this.createUserProfile(result.user.uid, {
        email,
        displayName: email.split("@")[0],
        subscription: { isPro: false, plan: "free" },
        preferences: { notifications: true, autoDelete: false, dailyGoal: 12 },
        stats: { totalScreenshots: 0, totalTasks: 0, completedTasks: 0, streakDays: 0 },
      })

      analytics.logEvent("sign_up", { method: "email" })
      return result.user
    } catch (error) {
      console.error("Sign up error:", error)
      throw error
    }
  }

  async signOut() {
    await auth.signOut()
    analytics.logEvent("logout")
  }

  onAuthStateChanged(callback: (user: any) => void) {
    return auth.onAuthStateChanged(callback)
  }

  // User profile methods
  async createUserProfile(uid: string, userData: Partial<User>) {
    await firestore
      .collection("users")
      .doc(uid)
      .set({
        uid,
        createdAt: new Date(),
        ...userData,
      })
  }

  async getUserProfile(uid: string): Promise<User | null> {
    const doc = await firestore.collection("users").doc(uid).get()
    return doc.exists ? (doc.data() as User) : null
  }

  async updateUserProfile(uid: string, updates: Partial<User>) {
    await firestore.collection("users").doc(uid).update(updates)
  }

  // Screenshot methods
  async uploadScreenshot(file: File, userId: string): Promise<Screenshot> {
    const screenshotId = Math.random().toString(36).substr(2, 9)
    const path = `screenshots/${userId}/${screenshotId}`

    // Upload to storage
    const uploadResult = await storage.ref(path).put(file)
    const url = await uploadResult.ref.getDownloadURL()

    // Create thumbnail (simulated)
    const thumbnailUrl = url + "?thumbnail=true"

    const screenshot: Screenshot = {
      id: screenshotId,
      userId,
      url,
      thumbnailUrl,
      extractedText: "", // Will be filled by OCR
      classification: "unprocessed",
      folder: "inbox",
      processed: false,
      createdAt: new Date(),
      metadata: {
        size: file.size,
        dimensions: { width: 0, height: 0 }, // Would be extracted from image
        source: "upload",
      },
    }

    // Save to Firestore
    await firestore.collection("screenshots").doc(screenshotId).set(screenshot)

    // Update user stats
    await this.incrementUserStat(userId, "totalScreenshots")

    analytics.logEvent("screenshot_uploaded", { userId, size: file.size })

    return screenshot
  }

  async getScreenshots(userId: string, folder?: string): Promise<Screenshot[]> {
    let query = firestore.collection("screenshots").where("userId", "==", userId)

    if (folder) {
      query = query.where("folder", "==", folder)
    }

    const result = await query.get()
    return result.docs.map((doc) => doc.data() as Screenshot)
  }

  async updateScreenshot(screenshotId: string, updates: Partial<Screenshot>) {
    await firestore.collection("screenshots").doc(screenshotId).update(updates)
  }

  async deleteScreenshot(screenshotId: string, userId: string) {
    // Soft delete - mark as deleted
    await firestore.collection("screenshots").doc(screenshotId).update({
      deletedAt: new Date(),
    })

    analytics.logEvent("screenshot_deleted", { userId, screenshotId })
  }

  // Task methods
  async createTask(task: TaskData): Promise<string> {
    const result = await firestore.collection("tasks").add(task)

    // Update user stats
    await this.incrementUserStat(task.userId, "totalTasks")

    analytics.logEvent("task_created", {
      userId: task.userId,
      category: task.category,
      urgency: task.urgency,
    })

    return result.id
  }

  async getTasks(userId: string, completed?: boolean): Promise<TaskData[]> {
    let query = firestore.collection("tasks").where("userId", "==", userId)

    if (completed !== undefined) {
      query = query.where("completed", "==", completed)
    }

    const result = await query.get()
    return result.docs.map((doc) => ({ ...doc.data(), id: doc.id }) as TaskData)
  }

  async updateTask(taskId: string, updates: Partial<TaskData>) {
    await firestore.collection("tasks").doc(taskId).update(updates)

    if (updates.completed === true) {
      const task = await firestore.collection("tasks").doc(taskId).get()
      const taskData = task.data() as TaskData

      await this.incrementUserStat(taskData.userId, "completedTasks")

      analytics.logEvent("task_completed", {
        userId: taskData.userId,
        category: taskData.category,
        timeToComplete: Date.now() - new Date(taskData.createdAt).getTime(),
      })
    }
  }

  async deleteTask(taskId: string) {
    await firestore.collection("tasks").doc(taskId).delete()
  }

  // Analytics and stats
  private async incrementUserStat(userId: string, stat: keyof User["stats"]) {
    const userRef = firestore.collection("users").doc(userId)
    const user = await userRef.get()

    if (user.exists) {
      const userData = user.data() as User
      const currentValue = userData.stats[stat] || 0
      await userRef.update({
        [`stats.${stat}`]: currentValue + 1,
      })
    }
  }

  async logAnalyticsEvent(eventName: string, parameters?: Record<string, any>) {
    analytics.logEvent(eventName, parameters)
  }

  // Subscription methods
  async updateSubscription(userId: string, isPro: boolean, plan: string, expiresAt?: Date) {
    await firestore.collection("users").doc(userId).update({
      "subscription.isPro": isPro,
      "subscription.plan": plan,
      "subscription.expiresAt": expiresAt,
    })

    analytics.logEvent("subscription_updated", { userId, plan, isPro })
  }

  // Folder management
  async createFolder(userId: string, name: string, type = "custom") {
    const folder = {
      id: Math.random().toString(36).substr(2, 9),
      userId,
      name,
      type,
      createdAt: new Date(),
      screenshotCount: 0,
    }

    await firestore.collection("folders").add(folder)
    return folder
  }

  async getFolders(userId: string) {
    const result = await firestore.collection("folders").where("userId", "==", userId).get()
    return result.docs.map((doc) => ({ ...doc.data(), id: doc.id }))
  }
}

export const firebaseService = new FirebaseService()
